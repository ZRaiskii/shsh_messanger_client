import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/entities/profile.dart';
import '../bloc/profile_bloc.dart';
import '../../domain/usecases/update_profile_usecase.dart';
import '../../../../core/utils/AppColors.dart';
import '../../../settings/data/services/theme_manager.dart';

import 'date_picker_content.dart';
import 'description_picker_content.dart';
import 'emoji_picker_content.dart';
import 'gender_switcher.dart';
import 'package:lottie/lottie.dart';

class ProfileInfo extends StatefulWidget {
  final Profile profile;
  final Future<void> Function() onPickImage;
  final Future<void> Function(String) onUpdateEmoji;
  final Future<void> Function(bool) onUpdatePremium;

  const ProfileInfo({
    super.key,
    required this.profile,
    required this.onPickImage,
    required this.onUpdateEmoji,
    required this.onUpdatePremium,
  });

  @override
  _ProfileInfoState createState() => _ProfileInfoState();
}

class _ProfileInfoState extends State<ProfileInfo>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _animation;
  bool _isFullScreen = false;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _animation = Tween<double>(begin: 0, end: 1).animate(_animationController)
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colors = isWhiteNotifier.value
        ? AppColors.light()
        : AppColors.dark(); // Получаем цвета в зависимости от темы

    return BlocBuilder<ProfileBloc, ProfileState>(
      builder: (context, state) {
        if (state is ProfileSuccess && state.profile != null) {
          return GestureDetector(
            onVerticalDragEnd: (details) {
              if (details.primaryVelocity! > 0) {
                _animationController.forward();
                setState(() {
                  _isFullScreen = true;
                });
              }
            },
            child: Stack(
              children: [
                SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Применяем Padding только к _buildProfileHeader
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: _buildProfileHeader(context, colors),
                      ),
                      const SizedBox(height: 16),
                      // _buildInfoSection без Padding
                      _buildInfoSection(context, colors),
                    ],
                  ),
                ),
                if (_isFullScreen)
                  GestureDetector(
                    onTap: () {
                      _animationController.reverse();
                      setState(() {
                        _isFullScreen = false;
                      });
                    },
                    child: AnimatedBuilder(
                      animation: _animation,
                      builder: (context, child) {
                        return Opacity(
                          opacity: _animation.value,
                          child: Container(
                            color: colors.backgroundColor.withOpacity(0.8),
                            child: Center(
                              child: CachedNetworkImage(
                                imageUrl: state.profile!.avatarUrl,
                                fit: BoxFit.contain,
                                placeholder: (context, url) =>
                                    CircularProgressIndicator(), // Опционально: индикатор загрузки
                                errorWidget: (context, url, error) => Icon(Icons
                                    .error), // Опционально: виджет при ошибке
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
              ],
            ),
          );
        } else {
          return Center(child: CircularProgressIndicator());
        }
      },
    );
  }

  Widget _buildProfileHeader(BuildContext context, AppColors colors) {
    // Проверяем, является ли nicknameEmoji Lottie-анимацией
    final bool isLottieEmoji =
        widget.profile.nicknameEmoji?.startsWith('assets/') ?? false;
    return Row(
      children: [
        GestureDetector(
          onTap: widget.onPickImage, // Используем onPickImage
          child: CircleAvatar(
            backgroundImage: widget.profile.avatarUrl.isNotEmpty
                ? NetworkImage(widget.profile.avatarUrl)
                : null,
            radius: 40,
            child: widget.profile.avatarUrl.isEmpty
                ? Icon(Icons.person, size: 40, color: colors.iconColor)
                : null,
          ),
        ),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: () => _showUsernameChangeDialog(context),
                  child: Text(
                    widget.profile.username,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: colors.textColor,
                        ),
                  ),
                ),
                const SizedBox(width: 8),
                if (widget.profile.premium &&
                    widget.profile.nicknameEmoji != null)
                  GestureDetector(
                    onTap: () {
                      _showEmojiPicker(context, widget.onUpdateEmoji, colors);
                    },
                    child: isLottieEmoji
                        ? SizedBox(
                            width: 24, // Размер Lottie-анимации
                            height: 24,
                            child: Lottie.asset(
                              widget.profile.nicknameEmoji!
                                  .replaceFirst('animation_emoji/', '')
                                  .replaceAll('', ''),
                              fit: BoxFit.contain,
                            ),
                          )
                        : Text(
                            widget.profile.nicknameEmoji!.isNotEmpty
                                ? widget.profile.nicknameEmoji!
                                : "⭐️",
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(
                                  color: colors.textColor,
                                ),
                          ),
                  ),
              ],
            ),
            Text(
              widget.profile.email,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: colors.textColor,
                  ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildInfoSection(BuildContext context, AppColors colors) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Заголовок "Информация" с отступами
        Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16.0), // Отступы по бокам
          child: Text(
            'Информация',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: colors.textColor,
                ),
          ),
        ),
        const SizedBox(height: 8), // Отступ между заголовком и контейнером
        // Контейнер с фоном, но без отступов
        Container(
          decoration: BoxDecoration(
            color: colors.appBarColor, // Цвет фона
            borderRadius: BorderRadius.circular(8), // Закруглённые углы
          ),
          child: Padding(
            padding: const EdgeInsets.all(8.0), // Отступы для содержимого
            child: Column(
              children: [
                // Добавляем строку "О себе" в блок "Информация"
                _buildInfoRow(
                  context,
                  Icons.info_outline, // Иконка для "О себе"
                  'О себе', // Заголовок
                  widget.profile.descriptionOfProfile.isEmpty
                      ? 'Добавьте описание'
                      : widget.profile.descriptionOfProfile, // Текст
                  colors,
                  () => _showDescriptionChangeDialog(
                      context), // Обработчик нажатия
                ),
                _buildDivider(colors),
                _buildInfoRow(
                  context,
                  Icons.email,
                  'Подтверждение почты',
                  widget.profile.isVerifiedEmail
                      ? "Подтверждено"
                      : "Не подтверждено",
                  colors,
                  () {
                    _showEmailVerificationDialog(context);
                  },
                ),
                _buildDivider(colors),
                _buildInfoRow(
                  context,
                  Icons.wc,
                  'Пол',
                  _getGenderTranslation(widget.profile.gender),
                  colors,
                  () {
                    _showGenderPickerDialog(context);
                  },
                ),
                _buildDivider(colors),
                _buildInfoRow(
                  context,
                  Icons.cake,
                  'Дата рождения',
                  formatDate(widget.profile.dateOfBirth),
                  colors,
                  () {
                    _showDatePickerDialog(context);
                  },
                ),
                _buildDivider(colors),
                _buildInfoRow(
                  context,
                  Icons.timer,
                  'Срок действия премиума',
                  formatDate(widget.profile.premiumExpiresAt),
                  colors,
                  () {
                    _showPremiumExpirationDialog(context);
                  },
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInfoRow(
    BuildContext context,
    IconData icon,
    String label,
    String value,
    AppColors colors,
    VoidCallback? onTap,
  ) {
    return Container(
      color: colors.backgroundColor.withOpacity(0.1), // Фон для всей строки
      child: Padding(
        padding:
            const EdgeInsets.symmetric(horizontal: 16.0), // Отступы по бокам
        child: ListTile(
          onTap: onTap, // Реакция на нажатие всей строки
          leading: Icon(
            icon,
            size: 18,
            color: colors.iconColor,
          ), // Уменьшенная иконка
          title: Text(
            value.isEmpty ? 'Добавьте описание' : value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: value.isEmpty
                      ? colors.textColor.withOpacity(0.5)
                      : colors.textColor,
                ),
          ),
          subtitle: Text(
            label,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color:
                      colors.textColor.withOpacity(0.7), // Более светлый текст
                ),
          ),
          contentPadding:
              const EdgeInsets.symmetric(vertical: 0.0), // Уменьшенные отступы
          dense: true, // Делаем строку более компактной
        ),
      ),
    );
  }

  Widget _buildDivider(AppColors colors) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 0.0),
      child: Divider(
        color: colors.dividerColor,
        thickness: 1,
      ),
    );
  }

  void _showEmojiPicker(
      BuildContext context, Function(String) onUpdateEmoji, AppColors colors) {
    showDialog(
      context: context,
      builder: (context) {
        return EmojiPickerContent(
          onUpdateEmoji: onUpdateEmoji,
          colors: colors,
        );
      },
    );
  }

  String formatDate(DateTime? date) {
    if (date == null) return 'Не указана';
    final day = date.day.toString().padLeft(2, '0');
    final month = date.month.toString().padLeft(2, '0');
    final year = date.year.toString();
    return '$day.$month.$year';
  }

  String _getGenderTranslation(String? gender) {
    if (gender == null) return 'Не указан';
    switch (gender.toUpperCase()) {
      case 'MALE':
        return 'Мужской';
      case 'FEMALE':
        return 'Женский';
      default:
        return 'Не указан';
    }
  }

  void _showUsernameChangeDialog(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Изменение имени пользователя',
            style: TextStyle(color: colors.textColor),
          ),
          content: Text(
            'Изменение имени пользователя временно недоступно. Пожалуйста, попробуйте позже.',
            style: TextStyle(color: colors.textColor),
          ),
          backgroundColor: colors.cardColor,
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                'ОК',
                style: TextStyle(color: colors.primaryColor),
              ),
            ),
          ],
        );
      },
    );
  }

  void _showPremiumExpirationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Уведомление'),
          content: Text(
              'Функциональность изменения срока премиума пока не реализована.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Закрыть диалог
              },
              child: Text('ОК'),
            ),
          ],
        );
      },
    );
  }

  void _showDatePickerDialog(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Выберите дату рождения',
            style: TextStyle(
                color: colors.textColor,
                fontSize: 20,
                fontWeight: FontWeight.bold),
          ),
          backgroundColor: colors.cardColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          content: DatePickerContent(colors: colors, profile: widget.profile),
        );
      },
    );
  }

  void _showGenderPickerDialog(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Выберите пол',
            style: TextStyle(
                color: colors.textColor,
                fontSize: 20,
                fontWeight: FontWeight.bold),
          ),
          backgroundColor: colors.cardColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          content: GenderPickerContent(colors: colors, profile: widget.profile),
        );
      },
    );
  }

  void _showEmailVerificationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Уведомление'),
          content:
              Text('Функциональность подтверждения почты пока не реализована.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Закрыть диалог
              },
              child: Text('ОК'),
            ),
          ],
        );
      },
    );
  }

  void _showDescriptionChangeDialog(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Изменить описание профиля',
            style: TextStyle(
                color: colors.textColor,
                fontSize: 20,
                fontWeight: FontWeight.bold),
          ),
          backgroundColor: colors.cardColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16.0),
          ),
          content: DescriptionPickerContent(
            colors: colors,
            profile: widget.profile,
          ),
        );
      },
    );
  }
}
