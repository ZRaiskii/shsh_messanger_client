import 'dart:io'; // Для проверки платформы
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/auth_bloc.dart';
import '../widgets/auth_card.dart';
import '../../../main/presentation/pages/main_page.dart';
import 'package:flutter_swiper_null_safety/flutter_swiper_null_safety.dart';
import 'package:shsh_social/core/widgets/new_year/new_year_snowfall.dart'; // Импортируем виджет снежинок

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  _AuthPageState createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<Color?> _colorAnimation;
  bool _isSnowfallEnabled = false;

  // Контроллеры для текстовых полей
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  // Контроллер для Swiper
  final SwiperController _swiperController = SwiperController();

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _colorAnimation = ColorTween(
      begin: Colors.blue,
      end: Colors.purple,
    ).animate(_animationController);
  }

  void _onPageChanged(int index) {
    index == 1
        ? _animationController.forward()
        : _animationController.reverse();
  }

  void _toggleSnowfall() {
    setState(() {
      _isSnowfallEnabled = !_isSnowfallEnabled;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: Stack(
        children: [
          if (_isSnowfallEnabled)
            NewYearSnowfall(
              isPlaying: false,
              animationType: "snowflakes",
              child: Container(),
            ),
          BlocListener<AuthBloc, AuthState>(
            listener: (context, state) {
              if (state is AuthFailure) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(state.message)),
                );
              } else if (state is AuthSuccess) {
                Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => MainPage()),
                );
              }
            },
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 50), // Отступ сверху для надписи "ЩЩ"
                  _buildAnimatedTitle(),
                  const SizedBox(height: 24),
                  Expanded(
                    child: Stack(
                      children: [
                        Swiper(
                          controller: _swiperController,
                          itemCount: 2,
                          onIndexChanged: _onPageChanged,
                          itemBuilder: (context, index) {
                            return index == 0
                                ? AuthCard(
                                    title: 'Вход',
                                    isLogin: true,
                                    onTap: () {
                                      _swiperController.next();
                                    },
                                    emailController: _emailController,
                                    passwordController: _passwordController,
                                  )
                                : AuthCard(
                                    title: 'Регистрация',
                                    isLogin: false,
                                    onTap: () {
                                      _swiperController.previous();
                                    },
                                    emailController: _emailController,
                                    passwordController: _passwordController,
                                    usernameController: _usernameController,
                                    confirmPasswordController:
                                        _confirmPasswordController,
                                  );
                          },
                          pagination: const SwiperPagination(
                            builder: DotSwiperPaginationBuilder(
                                activeColor: Colors.indigo, color: Colors.grey),
                          ),
                          control: const SwiperControl(),
                        ),
                        // Стрелки для навигации (только на Windows)
                        if (Platform.isWindows)
                          Positioned(
                            top: screenHeight * 0.4,
                            left: 0,
                            right: 0,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.arrow_back_ios,
                                      color: Colors.indigo),
                                  onPressed: () {
                                    _swiperController.previous();
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(Icons.arrow_forward_ios,
                                      color: Colors.indigo),
                                  onPressed: () {
                                    _swiperController.next();
                                  },
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildBottomLinks(),
                ],
              ),
            ),
          ),
          Positioned(
            top: 32,
            right: 16,
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.black54, // Фон для иконки
                shape: BoxShape.circle,
              ),
              child: IconButton(
                icon: Icon(
                  _isSnowfallEnabled ? Icons.close : Icons.snowing,
                  color: Colors.white, // Цвет иконки
                ),
                onPressed: _toggleSnowfall,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedTitle() {
    return AnimatedBuilder(
      animation: _colorAnimation,
      builder: (context, child) {
        return Text(
          'ЩЩ',
          style: TextStyle(
            fontSize: 64, // Увеличили размер шрифта
            fontWeight: FontWeight.bold,
            color: _colorAnimation.value,
            shadows: [
              Shadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(2, 2),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBottomLinks() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: GestureDetector(
        onTap: () => debugPrint('Забыл пароль нажато'),
        child: const Text(
          'Забыл пароль?',
          style: TextStyle(
            fontSize: 14,
            color: Colors.blue,
            decoration: TextDecoration.underline,
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _usernameController.dispose();
    _confirmPasswordController.dispose();
    _swiperController.dispose();
    super.dispose();
  }
}
