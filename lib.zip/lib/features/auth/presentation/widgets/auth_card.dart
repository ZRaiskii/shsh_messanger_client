import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/widgets/custom/custom_button.dart';
import '../../../../core/widgets/custom/custom_text_field.dart';
import '../../domain/usecases/login_usecase.dart';
import '../../domain/usecases/register_usecase.dart';
import '../bloc/auth_bloc.dart';

class AuthCard extends StatelessWidget {
  final String title;
  final bool isLogin;
  final VoidCallback onTap;
  final TextEditingController emailController;
  final TextEditingController passwordController;
  final TextEditingController? usernameController;
  final TextEditingController? confirmPasswordController;

  const AuthCard({
    required this.title,
    required this.isLogin,
    required this.onTap,
    required this.emailController,
    required this.passwordController,
    this.usernameController,
    this.confirmPasswordController,
    super.key,
  });

  bool _validateEmail(String email) {
    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    return emailRegex.hasMatch(email);
  }

  bool _validatePassword(String password) {
    final passwordRegex = RegExp(
        r'^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&.])[A-Za-z\d@$!%*#?&.]{8,}$');
    print(password);
    return passwordRegex.hasMatch(password);
  }

  bool _validateUsername(String username) {
    return username.length >= 5;
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: GestureDetector(
        onTap: onTap,
        child: SizedBox(
          width: 300, // Фиксированная ширина карточки
          child: Card(
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: SingleChildScrollView(
                // Добавлено для прокрутки
                child: Column(
                  mainAxisSize: MainAxisSize.min, // Минимальная высота
                  children: [
                    Text(
                      title,
                      style:
                          Theme.of(context).textTheme.headlineMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Crooker',
                              ),
                    ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: emailController,
                      hintText: 'Email',
                      keyboardType: TextInputType.emailAddress,
                      prefixIcon: Icons.email,
                    ),
                    const SizedBox(height: 16),
                    if (!isLogin)
                      CustomTextField(
                        controller: usernameController!,
                        hintText: 'Имя пользователя',
                        keyboardType: TextInputType.name,
                        prefixIcon: Icons.person,
                      ),
                    const SizedBox(height: 16),
                    CustomTextField(
                      controller: passwordController,
                      hintText: 'Пароль',
                      keyboardType: TextInputType.visiblePassword,
                      obscureText: true,
                      prefixIcon: Icons.lock,
                    ),
                    if (!isLogin) ...[
                      const SizedBox(height: 16),
                      CustomTextField(
                        controller: confirmPasswordController!,
                        hintText: 'Подтвердите пароль',
                        keyboardType: TextInputType.visiblePassword,
                        obscureText: true,
                        prefixIcon: Icons.lock,
                      ),
                    ],
                    const SizedBox(height: 24),
                    BlocBuilder<AuthBloc, AuthState>(
                      builder: (context, state) {
                        if (state is AuthLoading) {
                          return const CircularProgressIndicator();
                        }
                        return CustomButton(
                          onPressed: () {
                            final email = emailController.text;
                            final password = passwordController.text;
                            final username = usernameController?.text ?? '';
                            final confirmPassword =
                                confirmPasswordController?.text ?? '';

                            if (!_validateEmail(email)) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Введите корректный email')),
                              );
                              return;
                            }

                            if (!isLogin && !_validatePassword(password)) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text(
                                        'Пароль должен содержать минимум 8 символов, включая 1 букву, 1 цифру и 1 специальный символ')),
                              );
                              return;
                            }

                            if (!isLogin && !_validateUsername(username)) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text(
                                        'Никнейм должен содержать минимум 5 символов')),
                              );
                              return;
                            }

                            if (!isLogin && password != confirmPassword) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content: Text('Пароли не совпадают')),
                              );
                              return;
                            }

                            if (isLogin) {
                              context.read<AuthBloc>().add(
                                    LoginEvent(
                                      LoginParams(
                                        email: email,
                                        password: password,
                                      ),
                                    ),
                                  );
                            } else {
                              context.read<AuthBloc>().add(
                                    RegisterEvent(
                                      RegisterParams(
                                        email: email,
                                        username: username,
                                        password: password,
                                        confirmPassword: confirmPassword,
                                      ),
                                    ),
                                  );
                            }
                          },
                          text: title,
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
