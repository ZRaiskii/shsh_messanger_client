// lib/features/auth/data/datasources/auth_remote_datasource.dart
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../../../core/error/exceptions.dart';
import '../../../../core/utils/constants.dart';
import '../models/user_model.dart';

abstract class AuthRemoteDataSource {
  Future<UserModel> register(String email, String username, String password);
  Future<UserModel> login(String email, String password);
  Future<UserModel> refreshToken(String refreshToken);
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final http.Client client;

  AuthRemoteDataSourceImpl({required this.client});

  @override
  Future<UserModel> register(
      String email, String username, String password) async {
    print('Starting registration process');

    try {
      final response = await client.post(
        Uri.parse('${Constants.baseUrl}${Constants.registrationEndpoint}'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'username': username,
          'password': password,
          'confirmPassword': password,
        }),
      );

      print('Received response: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        print('Registration successful');
        return UserModel(
            email: "", id: '', refreshToken: '', token: '', username: "");
      } else {
        print('Registration failed with status code: ${response.statusCode}');
        throw ServerException();
      }
    } catch (e, stacktrace) {
      print('Exception occurred: $e  $stacktrace');
      throw ServerException();
    }
  }

  @override
  Future<UserModel> login(String email, String password) async {
    print('Starting login process');

    try {
      final response = await client.post(
        Uri.parse('${Constants.baseUrl}${Constants.loginEndpoint}'),
        headers: {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
        },
        body: json.encode({
          'email': email,
          'password': password,
        }),
      );

      print('Received response: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        print('Login successful');
        final jsonResponse = json.decode(utf8.decode(response.bodyBytes));
        print('Json req: $jsonResponse');
        return UserModel(
          id: jsonResponse['userId'],
          email: email,
          username: '', // Если username не возвращается, оставьте пустым
          token: jsonResponse['token'],
          refreshToken: jsonResponse['refreshToken'],
        );
      } else {
        print('Login failed with status code: ${response.statusCode}');
        throw ServerException();
      }
    } catch (e, stacktrace) {
      print('Exception occurred: $e');
      print('Stacktrace: $stacktrace');
      throw ServerException(e.toString());
    }
  }

  @override
  Future<UserModel> refreshToken(String refreshToken) async {
    final response = await client.post(
      Uri.parse('${Constants.baseUrl}${Constants.refreshTokenEndpoint}'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'refreshToken': refreshToken,
      }),
    );

    if (response.statusCode == 200) {
      return UserModel.fromJson(json.decode(utf8.decode(response.bodyBytes)));
    } else {
      throw ServerException();
    }
  }
}
