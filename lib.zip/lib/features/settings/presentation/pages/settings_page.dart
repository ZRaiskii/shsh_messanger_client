import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../../core/widgets/new_year/new_year_snowfall.dart';
import '../../../auth/presentation/pages/auth_page.dart';
import '../../../main/presentation/pages/main_page.dart';
import '../../../profile/presentation/pages/profile_page.dart';
import '../../data/services/theme_manager.dart';
import '../widgets/settings_form.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../../../core/data_base_helper.dart';
import '../../../../core/utils/AppColors.dart';
import '../../domain/entities/settings.dart';
import 'about_app_page.dart';
import 'chat_settings_page.dart';
import 'data_settings_page.dart';
import 'notification_settings_page.dart';
import 'premium_page.dart';

class SettingsPage extends StatelessWidget {
  void _showNotImplementedMessage(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Ещё не реализовано'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: isWhiteNotifier,
      builder: (context, isWhite, child) {
        final colors = isWhite ? AppColors.light() : AppColors.dark();

        return Scaffold(
          appBar: AppBar(
            automaticallyImplyLeading: false,
            title: Text(
              'Настройки',
              style: TextStyle(
                fontSize: 28.0,
                fontWeight: FontWeight.bold,
                color: colors.textColor,
              ),
            ),
            backgroundColor: colors.appBarColor,
            iconTheme: IconThemeData(color: colors.iconColor),
            actions: [
              IconButton(
                icon: Icon(Icons.bug_report, color: colors.iconColor),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => WebViewPage(
                        url:
                            'https://forms.yandex.ru/u/677d0b5502848f3b397e91a9/',
                        title: 'Отчет об ошибке',
                      ),
                    ),
                  );
                },
              ),
              IconButton(
                icon: Icon(isWhite ? Icons.wb_sunny : Icons.nights_stay,
                    color: colors.iconColor),
                onPressed: () async {
                  bool newTheme = !isWhiteNotifier.value;
                  await ThemeManager.setTheme(newTheme);
                  isWhiteNotifier.value = newTheme;
                  Navigator.of(context).popAndPushNamed('/main');
                },
              ),
              IconButton(
                icon: Icon(Icons.logout, color: colors.iconColor),
                onPressed: () async {
                  final colors = isWhiteNotifier.value
                      ? AppColors.light()
                      : AppColors.dark();
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        backgroundColor: colors.cardColor,
                        title: Text(
                          'Подтверждение выхода',
                          style: TextStyle(color: colors.textColor),
                        ),
                        content: Text(
                          'Вы уверены, что хотите выйти? Кеш будет очищен.',
                          style: TextStyle(color: colors.textColor),
                        ),
                        actions: <Widget>[
                          TextButton(
                            child: Text(
                              'Отмена',
                              style: TextStyle(color: colors.primaryColor),
                            ),
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                          ),
                          TextButton(
                            child: Text(
                              'Выйти',
                              style: TextStyle(color: colors.primaryColor),
                            ),
                            onPressed: () async {
                              Navigator.of(context).pop();
                              final prefs =
                                  await SharedPreferences.getInstance();
                              DatabaseHelper().clearDatabase();
                              await prefs.clear();
                              Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                    builder: (context) => AuthPage()),
                              );
                            },
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.only(top: 16.0), // Отступ сверху
            children: [
              // Основные настройки
              Card(
                margin:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                color: colors.cardColor, // Фон чуть светлее основного
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(Icons.chat, color: colors.iconColor),
                      title: Text('Настройки чатов',
                          style: TextStyle(color: colors.textColor)),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ChatSettingsPage()),
                        );
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.security, color: colors.iconColor),
                      title: Text('Конфиденциальность',
                          style: TextStyle(color: colors.textColor)),
                      onTap: () {
                        _showNotImplementedMessage(context);
                      },
                    ),
                    ListTile(
                      leading:
                          Icon(Icons.notifications, color: colors.iconColor),
                      title: Text('Уведомления и звуки',
                          style: TextStyle(color: colors.textColor)),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  NotificationsSettingsPage()),
                        );
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.storage, color: colors.iconColor),
                      title: Text('Данные и память',
                          style: TextStyle(color: colors.textColor)),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => DataSettingsPage()),
                        );
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.battery_charging_full,
                          color: colors.iconColor),
                      title: Text('Энергосбережение',
                          style: TextStyle(color: colors.textColor)),
                      onTap: () {
                        _showNotImplementedMessage(context);
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.language, color: colors.iconColor),
                      title: Text('Язык',
                          style: TextStyle(color: colors.textColor)),
                      trailing: Text(
                        'Русский',
                        style: TextStyle(
                          color: Colors.lightBlue, // Светло-синий цвет
                          fontSize: 16, // Размер текста
                        ),
                      ),
                      onTap: () {
                        _showNotImplementedMessage(context);
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.info, color: colors.iconColor),
                      title: Text('О приложении',
                          style: TextStyle(color: colors.textColor)),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => AboutAppPage()),
                        );
                      },
                    ),
                  ],
                ),
              ),
              // Блок с "ЩЩ Premium" и "Отправить подарок"
              Card(
                margin:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                color: colors.cardColor, // Фон чуть светлее основного
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(Icons.star, color: colors.iconColor),
                      title: Text('ЩЩ Premium',
                          style: TextStyle(color: colors.textColor)),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PremiumPage()),
                        );
                      },
                    ),
                    ListTile(
                      leading:
                          Icon(Icons.card_giftcard, color: colors.iconColor),
                      title: Text('Отправить подарок',
                          style: TextStyle(color: colors.textColor)),
                      onTap: () {
                        _showNotImplementedMessage(context);
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),
              // _buildSupportAuthorsButton(context, colors),
              // const SizedBox(height: 25),
            ],
          ),
          backgroundColor: colors.backgroundColor,
        );
      },
    );
  }

  Widget _buildSupportAuthorsButton(BuildContext context, AppColors colors) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: ElevatedButton.icon(
        onPressed: () async {
          launchUrlString('https://www.tbank.ru/cf/48e4IFH1Xm0');
        },
        icon: Icon(Icons.favorite, color: Colors.red),
        label: Text(
          'Поддержать авторов',
          style: TextStyle(fontSize: 16, color: colors.textColor),
        ),
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8.0),
          ),
          backgroundColor: colors.appBarColor,
        ),
      ),
    );
  }
}

class WebViewPage extends StatefulWidget {
  final String url;
  final String title;

  WebViewPage({required this.url, required this.title});

  @override
  _WebViewPageState createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  late WebViewController _controller;

  @override
  Widget build(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          style: TextStyle(color: colors.textColor), // Цвет текста AppBar
        ),
        backgroundColor: colors.appBarColor, // Цвет фона AppBar
        iconTheme: IconThemeData(color: colors.iconColor), // Цвет иконок AppBar
      ),
      body: WebViewWidget(
        controller: _controller,
      ),
      backgroundColor: colors.backgroundColor, // Цвет фона Scaffold
    );
  }

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));
  }
}
