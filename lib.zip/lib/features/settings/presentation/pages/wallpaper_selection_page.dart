import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../../../../core/utils/AppColors.dart';
import '../../data/services/theme_manager.dart'; // Добавляем Provider для доступа к isWhiteNotifier

class WallpaperSelectionPage extends StatefulWidget {
  @override
  _WallpaperSelectionPageState createState() => _WallpaperSelectionPageState();
}

class _WallpaperSelectionPageState extends State<WallpaperSelectionPage> {
  final ImagePicker _picker = ImagePicker();
  final ValueNotifier<String?> _selectedAssetNotifier =
      ValueNotifier<String?>(null);
  File? _selectedImage;

  @override
  void initState() {
    super.initState();
    _loadSelectedAsset();
  }

  Future<void> _loadSelectedAsset() async {
    final prefs = await SharedPreferences.getInstance();
    final selectedAsset = prefs.getString('selected');
    if (selectedAsset != null) {
      if (selectedAsset.startsWith('/')) {
        _selectedImage = File(selectedAsset);
      }
      _selectedAssetNotifier.value = selectedAsset;
    }
  }

  Future<void> _pickImage() async {
    final XFile? pickedFile = await _picker.pickImage(
      source: ImageSource.gallery,
      maxHeight: 1080,
      maxWidth: 1920,
    );

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
      _saveBackgroundImage(pickedFile.path);
      _saveBackgroundPath(pickedFile.path);
      _selectedAssetNotifier.value = pickedFile.path;
    }
  }

  Future<void> _saveBackgroundImage(String imagePath) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('background_image', imagePath);
  }

  Future<void> _saveBackgroundPath(String imagePath) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('selected', imagePath);
  }

  Future<void> _copyAssetAndSave(String assetPath) async {
    final byteData = await rootBundle.load(assetPath);
    final directory = await getApplicationDocumentsDirectory();
    final file = File('${directory.path}/${assetPath.split('/').last}');
    await file.writeAsBytes(byteData.buffer
        .asUint8List(byteData.offsetInBytes, byteData.lengthInBytes));
    _saveBackgroundImage(file.path);
    _saveBackgroundPath(assetPath);
    setState(() {
      _selectedImage = null;
    });
    _selectedAssetNotifier.value = assetPath;
  }

  Future<void> _clearSelection() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('background_image');
    await prefs.remove('selected');
    setState(() {
      _selectedImage = null;
    });
    _selectedAssetNotifier.value = null;
  }

  @override
  Widget build(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Обои для чатов',
          style: TextStyle(
              color: colors.textColor), // Используем цвет текста из AppColors
        ),
        backgroundColor:
            colors.appBarColor, // Используем цвет фона AppBar из AppColors
        iconTheme: IconThemeData(
            color: colors.iconColor), // Используем цвет иконок из AppColors
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color:
                      colors.appBarColor, // Используем цвет фона из AppColors
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.photo_library,
                      color: colors
                          .iconColor, // Используем цвет иконки из AppColors
                      size: 24.0,
                    ),
                    SizedBox(width: 8.0),
                    Text(
                      'Выбрать из галереи',
                      style: TextStyle(
                        color: colors
                            .textColor, // Используем цвет текста из AppColors
                        fontSize: 16.0,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 16.0),
            Text(
              'Стандартные обои',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
                color: colors.textColor, // Используем цвет текста из AppColors
              ),
            ),
            SizedBox(height: 16.0),
            Expanded(
              child: ValueListenableBuilder<String?>(
                valueListenable: _selectedAssetNotifier,
                builder: (context, selectedAsset, child) {
                  return GridView.count(
                    crossAxisCount: 3,
                    crossAxisSpacing: 8.0,
                    mainAxisSpacing: 8.0,
                    children: [
                      GestureDetector(
                        onTap: _clearSelection,
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8.0),
                            border: Border.all(color: Colors.red, width: 2.0),
                          ),
                          child: Center(
                            child: Icon(
                              Icons.cancel,
                              color: Colors.red,
                              size: 48.0,
                            ),
                          ),
                        ),
                      ),
                      if (_selectedImage != null)
                        GestureDetector(
                          onTap: () {
                            _saveBackgroundImage(_selectedImage!.path);
                            _saveBackgroundPath(_selectedImage!.path);
                            _selectedAssetNotifier.value = _selectedImage!.path;
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              image: DecorationImage(
                                image: FileImage(_selectedImage!),
                                fit: BoxFit.cover,
                              ),
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                color: colors.backgroundColor.withOpacity(
                                    0.5), // Используем цвет фона из AppColors
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              child: Center(
                                child: Icon(
                                  Icons.check,
                                  color: colors
                                      .iconColor, // Используем цвет иконки из AppColors
                                  size: 32.0,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ...List.generate(10, (index) {
                        final assetPath = 'assets/wallpaper_$index.jpg';
                        return GestureDetector(
                          onTap: () {
                            _copyAssetAndSave(assetPath);
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              image: DecorationImage(
                                image: AssetImage(assetPath),
                                fit: BoxFit.cover,
                              ),
                            ),
                            child: selectedAsset == assetPath
                                ? Container(
                                    decoration: BoxDecoration(
                                      color: colors.backgroundColor.withOpacity(
                                          0.5), // Используем цвет фона из AppColors
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    child: Center(
                                      child: Icon(
                                        Icons.check,
                                        color: colors
                                            .iconColor, // Используем цвет иконки из AppColors
                                        size: 32.0,
                                      ),
                                    ),
                                  )
                                : null,
                          ),
                        );
                      }),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
