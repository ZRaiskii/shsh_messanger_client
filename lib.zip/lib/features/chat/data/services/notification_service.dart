import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:win_toast/win_toast.dart';
import 'package:windows_notification/windows_notification.dart';
import 'package:windows_notification/notification_message.dart';

import '../../../../core/app_settings.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  final GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();
  final WindowsNotification _winNotifyPlugin = WindowsNotification(
    applicationId: "Уведомление от ЩЩ",
  );

  int id = 0;

  NotificationService() {
    if (kIsWeb) {
      return;
    }
    if (Platform.isWindows) {
      _initializeWindowsNotifications();
      return;
    }
    _configureLocalTimeZone();
    _initializeNotifications();
  }

  Future<void> _configureLocalTimeZone() async {
    if (kIsWeb || Platform.isLinux) {
      return;
    }
    tz.initializeTimeZones();
    final String? timeZoneName = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(timeZoneName!));
  }

  Future<void> _initializeNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('icon');

    final InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: const DarwinInitializationSettings(),
      macOS: const DarwinInitializationSettings(),
      linux: const LinuxInitializationSettings(
        defaultActionName: 'Open notification',
      ),
    );

    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse:
          (NotificationResponse notificationResponse) {
        // Обработка нажатия на уведомление
      },
      onDidReceiveBackgroundNotificationResponse: null,
    );
  }

  Future<String> _copyIconToFileSystem() async {
    try {
      final Directory tempDir = await getTemporaryDirectory();
      final String tempPath = tempDir.path;

      final String iconPath = '$tempPath/shsh.ico';

      final File file = File(iconPath);
      if (await file.exists()) {
        await file.delete();
        print('Старая иконка удалена: $iconPath');
      }

      final ByteData data = await rootBundle.load('assets/icons/shsh.ico');
      print('Иконка загружена из assets.');

      await file.writeAsBytes(data.buffer.asUint8List());
      print('Иконка успешно записана: $iconPath');

      return iconPath;
    } catch (e) {
      print('Ошибка при копировании иконки: $e');
      rethrow;
    }
  }

  Future<void> _initializeWindowsNotifications() async {
    try {
      final String iconPath = await _copyIconToFileSystem();

      if (iconPath.isEmpty) {
        throw Exception('Путь к иконке не был загружен.');
      }

      final File iconFile = File(iconPath);
      if (!await iconFile.exists()) {
        throw Exception('Файл иконки не существует: $iconPath');
      }

      await WinToast.instance().initialize(
        aumId: 'com.shshInc.shsh', // Уникальный идентификатор приложения
        displayName: 'ЩЩ', // Название приложения
        iconPath: iconPath, // Путь к иконке
        clsid:
            '{550e8400-e29b-41d4-a716-446655440000}', // Уникальный идентификатор (GUID)
      );

      print('WinToast успешно инициализирован.');
    } catch (e) {
      print('Ошибка при инициализации WinToast: $e');
      rethrow;
    }
  }

  /// Метод для замены Lottie-анимации на emoji
  String _getReplacementEmoji(String body) {
    // Извлекаем имя файла из пути
    final String fileName = body.split('/').last.split('.').first;

    switch (fileName) {
      case '100':
        return '💯'; // 100 баллов
      case 'alarm-clock':
        return '⏰'; // Будильник
      case 'battary-full':
        return '🔋'; // Полная батарея
      case 'battary-low':
        return '🪫'; // Разряженная батарея
      case 'birthday-cake':
        return '🎂'; // Торт на день рождения
      case 'blood':
        return '🩸'; // Кровь
      case 'blush':
        return '😊'; // Улыбка с румянцем
      case 'bomb':
        return '💣'; // Бомба
      case 'bowling':
        return '🎳'; // Боулинг
      case 'broking-heart':
        return '💔'; // Разбитое сердце
      case 'chequered-flag':
        return '🏁'; // Клетчатый флаг
      case 'chinking-beer-mugs':
        return '🍻'; // Бокалы пива
      case 'clap':
        return '👏'; // Аплодисменты
      case 'clown':
        return '🤡'; // Клоун
      case 'cold-face':
        return '🥶'; // Холодное лицо
      case 'collision':
        return '💥'; // Столкновение
      case 'confetti-ball':
        return '🎊'; // Конфетти
      case 'cross-mark':
        return '❌'; // Крестик
      case 'crossed-fingers':
        return '🤞'; // Скрёщенные пальцы
      case 'crystal-ball':
        return '🔮'; // Хрустальный шар
      case 'cursing':
        return '🤬'; // Ругательство
      case 'die':
        return '🎲'; // Игральная кость
      case 'dizy-dace':
        return '😵'; // Головокружение
      case 'drool':
        return '🤤'; // Слюни
      case 'exclamation':
        return '❗'; // Восклицательный знак
      case 'experssionless':
        return '😑'; // Без выражения
      case 'eyes':
        return '👀'; // Глаза
      case 'fire':
        return '🔥'; // Огонь
      case 'folded-hands':
        return '🙏'; // Сложенные руки
      case 'gear':
        return '⚙️'; // Шестерёнка
      case 'grimacing':
        return '😬'; // Гримаса
      case 'Grin':
        return '😁'; // Широкая улыбка
      case 'Grinning':
        return '😀'; // Улыбка
      case 'halo':
        return '😇'; // Ореол
      case 'heart-eyes':
        return '😍'; // Сердечные глаза
      case 'heart-face':
        return '🥰'; // Лицо с сердечками
      case 'holding-back-tears':
        return '🥹'; // Сдерживающий слёзы
      case 'hot-face':
        return '🥵'; // Горячее лицо
      case 'hug-face':
        return '🤗'; // Обнимающее лицо
      case 'imp-smile':
        return '😈'; // Улыбка с рожками
      case 'Joy':
        return '😂'; // Слёзы радости
      case 'kiss':
        return '💋'; // Поцелуй
      case 'Kissing-closed-eyes':
        return '😚'; // Поцелуй с закрытыми глазами
      case 'Kissing-heart':
        return '😘'; // Поцелуй с сердечком
      case 'Kissing':
        return '😗'; // Поцелуй
      case 'Launghing':
        return '😆'; // Смех
      case 'light-bulb':
        return '💡'; // Лампочка
      case 'Loudly-crying':
        return '😭'; // Громкий плач
      case 'melting':
        return '🫠'; // Таящее лицо
      case 'mind-blown':
        return '🤯'; // Взорванный мозг
      case 'money-face':
        return '🤑'; // Лицо с деньгами
      case 'money-wings':
        return '💸'; // Деньги с крыльями
      case 'mouth-none':
        return '😶'; // Лицо без рта
      case 'muscle':
        return '💪'; // Мускулы
      case 'neutral-face':
        return '😐'; // Нейтральное лицо
      case 'party-popper':
        return '🎉'; // Хлопушка
      case 'partying-face':
        return '🥳'; // Лицо на вечеринке
      case 'pencil':
        return '✏️'; // Карандаш
      case 'pensive':
        return '😔'; // Задумчивое лицо
      case 'pig':
        return '🐷'; // Свинья
      case 'pleading':
        return '🥺'; // Умоляющее лицо
      case 'poop':
        return '💩'; // Какашка
      case 'question':
        return '❓'; // Вопросительный знак
      case 'rainbow':
        return '🌈'; // Радуга
      case 'raised-eyebrow':
        return '🤨'; // Поднятая бровь
      case 'relieved':
        return '😌'; // Облегчение
      case 'revolving-heart':
        return '💞'; // Вращающееся сердце
      case 'Rofl':
        return '🤣'; // Катающийся от смеха
      case 'roling-eyes':
        return '🙄'; // Закатывание глаз
      case 'salute':
        return '🫡'; // Салют
      case 'screaming':
        return '😱'; // Крик
      case 'shushing-face':
        return '🤫'; // Тихое лицо
      case 'skull':
        return '💀'; // Череп
      case 'sleep':
        return '😴'; // Сон
      case 'slot-machine':
        return '🎰'; // Игровой автомат
      case 'smile':
        return '😊'; // Улыбка
      case 'smile_with_big_eyes':
        return '😄'; // Улыбка с большими глазами
      case 'smirk':
        return '😏'; // Ухмылка
      case 'soccer-bal':
        return '⚽'; // Футбольный мяч
      case 'sparkles':
        return '✨'; // Блёстки
      case 'stuck-out-tongue':
        return '😛'; // Высунутый язык
      case 'subglasses-face':
        return '😎'; // Лицо в очках
      case 'thermometer-face':
        return '🤒'; // Лицо с термометром
      case 'thinking-face':
        return '🤔'; // Задумчивое лицо
      case 'thumbs-down':
        return '👎'; // Большой палец вниз
      case 'thumbs-up':
        return '👍'; // Большой палец вверх
      case 'upside-down-face':
        return '🙃'; // Перевёрнутое лицо
      case 'victory':
        return '✌️'; // Победа
      case 'vomit':
        return '🤮'; // Рвота
      case 'warm-smile':
        return '☺️'; // Тёплая улыбка
      case 'wave':
        return '👋'; // Волна
      case 'Wink':
        return '😉'; // Подмигивание
      case 'winky-tongue':
        return '😜'; // Подмигивание с языком
      case 'woozy':
        return '🥴'; // Одурманенный
      case 'yawn':
        return '🥱'; // Зевота
      case 'yum':
        return '😋'; // Вкусно
      case 'zany-face':
        return '🤪'; // Сумасшедшее лицо
      case 'zipper-face':
        return '🤐'; // Лицо с молнией
      default:
        return '✨'; // Emoji по умолчанию, если имя файла не распознано
    }
  }

  Future<void> showNotification({
    required String title,
    required String body,
    String? payload,
  }) async {
    if (kIsWeb) {
      return;
    }

    // Проверяем, включены ли уведомления в приложении
    if (!AppSettings.inAppNotifications) {
      return; // Если уведомления выключены, ничего не делаем
    }

    // Проверяем, является ли сообщение Lottie-анимацией
    final bool isLottieMessage = body.startsWith('::animation_emoji/');

    // Если это Lottie-анимация, заменяем её на обычный emoji
    final String notificationBody =
        isLottieMessage ? _getReplacementEmoji(body) : body;

    if (Platform.isWindows) {
      final String iconPath = await _copyIconToFileSystem();

      final message = NotificationMessage.fromPluginTemplate(
        "notification_${DateTime.now().millisecondsSinceEpoch}", // Уникальный ID
        title,
        notificationBody, // Используем заменённое тело уведомления
        image: iconPath,
        launch: payload, // Дополнительные данные (опционально)
      );

      // Показываем уведомление
      _winNotifyPlugin.showNotificationPluginTemplate(message);
      return;
    }

    // Настройки для Android уведомлений
    AndroidNotificationDetails androidNotificationDetails =
        AndroidNotificationDetails(
      'your_channel_id',
      'your_channel_name',
      channelDescription: 'your_channel_description',
      importance: Importance.max,
      priority: Priority.high,
      ticker: 'ticker',
      sound: AppSettings.soundEnabled
          ? RawResourceAndroidNotificationSound('notification_sound')
          : null,
      enableVibration: AppSettings.vibrationEnabled,
    );

    final NotificationDetails notificationDetails =
        NotificationDetails(android: androidNotificationDetails);

    // Показываем уведомление с заменённым телом
    await flutterLocalNotificationsPlugin.show(
      id++,
      title,
      notificationBody,
      notificationDetails,
      payload: payload,
    );
  }

  Future<void> showBackgroundNotification() async {
    if (Platform.isWindows) {
      // // Используем win_toast для Windows
      // WinToast.instance().showToast(
      //   toast: Toast(
      //     children: [
      //       ToastText('Приложение ЩЩ'), // Заголовок уведомления
      //       ToastText('Работает в фоновом режиме'), // Текст уведомления
      //     ],
      //     duration: ToastDuration.short, // Длительность уведомления
      //   ),
      // );
      return;
    }

    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'background_channel',
      'Фоновый режим',
      channelDescription: 'Уведомления о работе приложения в фоновом режиме',
      importance: Importance.high,
      priority: Priority.high,
      showWhen: false,
      ongoing: true,
    );

    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);

    await flutterLocalNotificationsPlugin.show(
      0,
      'Приложение ЩЩ',
      'Работает в фоновом режиме',
      platformChannelSpecifics,
    );
  }

  void _onReceiveTaskData(Object data) {
    if (data is Map<String, dynamic>) {
      final dynamic timestampMillis = data["timestampMillis"];
      if (timestampMillis != null) {
        final DateTime timestamp =
            DateTime.fromMillisecondsSinceEpoch(timestampMillis, isUtc: true);
      }
    }
  }

  Future<bool> _loadNotificationsEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('notifications_enabled') ?? true;
  }
}
