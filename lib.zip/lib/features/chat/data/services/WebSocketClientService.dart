import 'dart:async';
import 'dart:convert';

import 'package:stomp_dart_client/stomp_dart_client.dart';

import '../../../auth/data/models/user_model.dart';
import '../../domain/entities/message.dart';
import 'notification_service.dart';
import 'shared_preferences_singleton.dart';

class WebSocketClientServiceForWorkManager {
  StompClient? stompClient;
  final NotificationService notificationService;

  WebSocketClientServiceForWorkManager({required this.notificationService});

  Future<void> connect() async {
    if (stompClient != null && stompClient!.connected) {
      return;
    }

    try {
      final prefs = await SharedPreferencesSingleton.getInstance().value;
      final cachedUser = prefs.getString('cached_user');
      if (cachedUser != null) {
        final user =
            UserModel.fromJson(json.decode(cachedUser) as Map<String, dynamic>);
        if (user.token != null && user.token!.isNotEmpty) {
          stompClient = StompClient(
            config: StompConfig(
              url: 'ws://90.156.171.188:8080/ws?userId=${user.id}',
              onConnect: onConnect,
              stompConnectHeaders: {'Authorization': 'Bearer ${user.token}'},
              onWebSocketError: (dynamic error) => _handleWebSocketError(error),
              onStompError: (StompFrame frame) => _handleStompError(frame),
              onDisconnect: (StompFrame frame) => _handleDisconnect(frame),
            ),
          );
          stompClient?.activate();
        }
      }
    } catch (e) {
      _scheduleReconnect();
    }
  }

  Future<void> onConnect(StompFrame connectFrame) async {
    final prefs = await SharedPreferencesSingleton.getInstance().value;
    final cachedUser = prefs.getString('cached_user');
    if (cachedUser != null) {
      final user =
          UserModel.fromJson(json.decode(cachedUser) as Map<String, dynamic>);
      stompClient?.subscribe(
        destination: '/user/${user.id}/queue/messages',
        callback: (StompFrame frame) {
          var msg = json.decode(frame.body!);
          print(msg);
          displayMessage(msg);
        },
      );
    }
  }

  void displayMessage(Map<String, dynamic> msg) async {
    final message = Message.fromJson(msg);
    notificationService.showNotification(
      title: 'Новое сообщение',
      body: message.content,
    );
  }

  void _handleWebSocketError(dynamic error) {
    _scheduleReconnect();
  }

  void _handleStompError(StompFrame frame) {
    _scheduleReconnect();
  }

  void _handleDisconnect(StompFrame frame) {
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    Timer(Duration(seconds: 5), () => connect());
  }
}
