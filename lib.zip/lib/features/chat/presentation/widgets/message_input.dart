import 'dart:async';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:pasteboard/pasteboard.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_view/photo_view.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../../core/utils/windows_clipboard.dart';
import '../../../auth/data/models/user_model.dart';
import '../../../../core/utils/constants.dart';
import '../../domain/entities/message.dart';
import '../../../../core/utils/AppColors.dart';
import '../../../settings/data/services/theme_manager.dart'; // Импортируем AppColors

import '../../data/services/chat_state_manager.dart';
import 'custom_text_selection_controls.dart';
import 'photo_editor/pages/photo_editor_page.dart';
import 'package:flutter/services.dart';

import 'package:lottie/lottie.dart';

class MessageInput extends StatefulWidget {
  final String? chatId;
  final String userId;
  final String recipientId;
  final Function(String) onSend;
  final Function(String) onSendPhoto;
  final Function(bool) typing;
  final ValueNotifier<Message?> replyMessageNotifier;
  final Function({
    required String messageId,
    required String chatId,
    required String senderId,
    required String newContent,
  }) onEditMessage;

  const MessageInput({
    this.chatId,
    required this.userId,
    required this.recipientId,
    required this.onSend,
    required this.onSendPhoto,
    required this.typing,
    required this.replyMessageNotifier,
    required this.onEditMessage,
    super.key,
  });

  @override
  _MessageInputState createState() => _MessageInputState();
}

class _MessageInputState extends State<MessageInput> {
  final TextEditingController _controller = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  bool _isShiftPressed = false;
  bool _isControlPressed = false;
  final FocusNode _focusNode = FocusNode();
  bool _showEmojiPicker = false;
  Timer? _typingTimer;
  final ValueNotifier<bool> _hasTextNotifier = ValueNotifier<bool>(false);

  @override
  void initState() {
    super.initState();
    RawKeyboard.instance.addListener(_handleKeyEvent);
    _controller.addListener(_onTextChanged);
    ChatStateManager.instance.editingMessageNotifier
        .addListener(_updateEditingMessage);
  }

  void _onTextChanged() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _hasTextNotifier.value = _controller.text.isNotEmpty;
    });
  }

  @override
  void dispose() {
    RawKeyboard.instance.removeListener(_handleKeyEvent);
    _focusNode.dispose();
    _typingTimer?.cancel();
    ChatStateManager.instance.editingMessageNotifier
        .removeListener(_updateEditingMessage);
    super.dispose();
  }

  void _updateEditingMessage() {
    final editingMessage =
        ChatStateManager.instance.editingMessageNotifier.value;
    if (editingMessage != null) {
      setState(() {
        _controller.text = editingMessage.content;
        _controller.selection = TextSelection.fromPosition(
          TextPosition(offset: _controller.text.length),
        );
      });
    }
  }

  // Метод для отмены редактирования
  void _cancelEditing() {
    ChatStateManager.instance.editingMessageNotifier.value = null;
    _controller.clear();
  }

  // Метод для отправки измененного сообщения
  void _sendEditedMessage() {
    final editedMessage =
        ChatStateManager.instance.editingMessageNotifier.value;
    if (editedMessage != null) {
      final newContent = _controller.text.trim(); // Удаляем лишние пробелы

      // Проверяем, изменилось ли сообщение
      if (newContent.isNotEmpty && newContent != editedMessage.content) {
        _sendTypingStatus(false);
        widget.onEditMessage(
          messageId: editedMessage.id,
          chatId: widget.chatId!,
          senderId: widget.userId,
          newContent: newContent,
        );
        _cancelEditing();
      } else {
        // Если сообщение не изменилось или пустое, показываем уведомление
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Сообщение не изменилось или пустое.'),
          ),
        );
      }
    }
  }

  // Метод для отправки статуса печатания
  void _sendTypingStatus(bool isTyping) {
    if (widget.chatId != null) {
      widget.typing(isTyping);
    }
  }

  void _startTypingTimer() {
    // _typingTimer?.cancel();

    _sendTypingStatus(true);

    _typingTimer = Timer(Duration(milliseconds: 1500), () {
      // _sendTypingStatus(false);
    });
  }

  void _handleKeyEvent(RawKeyEvent event) {
    if (Platform.isWindows &&
        ChatStateManager.instance.editingMessageNotifier.value == null) {
      if (event is RawKeyDownEvent) {
        // Handle Shift + Enter for new line
        if (event.isShiftPressed &&
            event.logicalKey == LogicalKeyboardKey.enter) {
          final currentText = _controller.text;
          final currentSelection = _controller.selection;

          // Insert a new line at the current cursor position
          final newText = currentText.replaceRange(
            currentSelection.start,
            currentSelection.end,
            '\n',
          );

          // Update the controller with the new text and move the cursor
          _controller.value = TextEditingValue(
            text: newText,
            selection:
                TextSelection.collapsed(offset: currentSelection.start + 1),
          );
          if (ChatStateManager.instance.editingMessageNotifier.value != null) {
            ChatStateManager.instance.editingMessageNotifier.value?.content =
                newText;
          }
          return; // Exit the method after handling Shift + Enter
        }
        // Handle Enter to send message
        else if (event.logicalKey == LogicalKeyboardKey.enter) {
          _sendMessage();
          return; // Exit the method after handling Enter
        }

        // Handle Ctrl key press
        if (event.logicalKey == LogicalKeyboardKey.controlLeft ||
            event.logicalKey == LogicalKeyboardKey.controlRight) {
          setState(() {
            _isControlPressed = true;
          });
        }

        // Handle Ctrl + V for paste
        if (_isControlPressed && event.logicalKey == LogicalKeyboardKey.keyV) {
          _pasteImageFromClipboard();
        }
      } else if (event is RawKeyUpEvent) {
        // Handle Shift key release
        if (event.logicalKey == LogicalKeyboardKey.shiftLeft ||
            event.logicalKey == LogicalKeyboardKey.shiftRight) {
          setState(() {
            _isShiftPressed = false;
          });
        }

        // Handle Ctrl key release
        if (event.logicalKey == LogicalKeyboardKey.controlLeft ||
            event.logicalKey == LogicalKeyboardKey.controlRight) {
          setState(() {
            _isControlPressed = false;
          });
        }
      }
    }
  }

  Future<void> _pasteImageFromClipboard() async {
    if (Platform.isWindows) {
      try {
        final imageBytes = await Pasteboard.image;

        if (imageBytes != null) {
          final tempDir = await getTemporaryDirectory();
          final imageFile = File('${tempDir.path}/pasted_image.png');
          await imageFile.writeAsBytes(imageBytes);

          if (mounted) {
            _showPhotoEditor(imageFile);
          }
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('В буфере обмена нет изображения.'),
              ),
            );
          }
        }
      } catch (e) {
        print(e);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Ошибка при вставке изображения: $e'),
            ),
          );
        }
      }
    }
  }

  void _sendMessage() {
    final message = _controller.text.trim();
    if (message.isNotEmpty) {
      widget.onSend(message);
      _sendTypingStatus(false);
      _controller.clear();
      _focusNode.requestFocus();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Сообщение не может быть пустым.'),
        ),
      );
    }
  }

  bool isPhotoUrl(String text) {
    return text.startsWith('http') &&
        (text.endsWith('.jpg') ||
            text.endsWith('.png') ||
            text.endsWith('.jpeg'));
  }

  final Map<String, List<String>> animatedEmojiCategories = {
    'Анимации': [
      // Лица и эмоции
      'assets/heart_emoji.json', // Сердце
      'assets/laughing_emoji.json', // Смеющийся emoji
      'assets/crying_emoji.json', // Плачущий emoji
      'assets/angry_emoji.json', // Сердитый emoji
      'assets/blush.json', // Улыбка с румянцем
      'assets/experssionless.json', // Без выражения
      'assets/Grin.json', // Широкая улыбка
      'assets/Grinning.json', // Улыбка
      'assets/halo.json', // Ореол
      'assets/heart-eyes.json', // Сердечные глаза
      'assets/heart-face.json', // Лицо с сердечками
      'assets/holding-back-tears.json', // Сдерживающий слёзы
      'assets/hot-face.json', // Горячее лицо
      'assets/hug-face.json', // Обнимающее лицо
      'assets/imp-smile.json', // Улыбка с рожками
      'assets/Joy.json', // Слёзы радости
      'assets/kiss.json', // Поцелуй
      'assets/Kissing-closed-eyes.json', // Поцелуй с закрытыми глазами
      'assets/Kissing-heart.json', // Поцелуй с сердечком
      'assets/Kissing.json', // Поцелуй
      'assets/Launghing.json', // Смех
      'assets/Loudly-crying.json', // Громкий плач
      'assets/melting.json', // Таящее лицо
      'assets/mind-blown.json', // Взорванный мозг
      'assets/money-face.json', // Лицо с деньгами
      'assets/neutral-face.json', // Нейтральное лицо
      'assets/partying-face.json', // Лицо на вечеринке
      'assets/pensive.json', // Задумчивое лицо
      'assets/pleading.json', // Умоляющее лицо
      'assets/raised-eyebrow.json', // Поднятая бровь
      'assets/relieved.json', // Облегчение
      'assets/Rofl.json', // Катающийся от смеха
      'assets/roling-eyes.json', // Закатывание глаз
      'assets/screaming.json', // Крик
      'assets/shushing-face.json', // Тихое лицо
      'assets/skull.json', // Череп
      'assets/sleep.json', // Сон
      'assets/smile.json', // Улыбка
      'assets/smile_with_big_eyes.json', // Улыбка с большими глазами
      'assets/smirk.json', // Ухмылка
      'assets/stuck-out-tongue.json', // Высунутый язык
      'assets/subglasses-face.json', // Лицо в очках
      'assets/thermometer-face.json', // Лицо с термометром
      'assets/thinking-face.json', // Задумчивое лицо
      'assets/upside-down-face.json', // Перевёрнутое лицо
      'assets/vomit.json', // Рвота
      'assets/warm-smile.json', // Тёплая улыбка
      'assets/Wink.json', // Подмигивание
      'assets/winky-tongue.json', // Подмигивание с языком
      'assets/woozy.json', // Одурманенный
      'assets/yawn.json', // Зевота
      'assets/yum.json', // Вкусно
      'assets/zany-face.json', // Сумасшедшее лицо
      'assets/zipper-face.json', // Лицо с молнией

      // Остальные анимации
      'assets/100.json', // 100 баллов
      'assets/alarm-clock.json', // Будильник
      'assets/battary-full.json', // Полная батарея
      'assets/battary-low.json', // Разряженная батарея
      'assets/birthday-cake.json', // Торт на день рождения
      'assets/blood.json', // Кровь
      'assets/bomb.json', // Бомба
      'assets/bowling.json', // Боулинг
      'assets/broking-heart.json', // Разбитое сердце
      'assets/chequered-flag.json', // Клетчатый флаг
      'assets/chinking-beer-mugs.json', // Бокалы пива
      'assets/clap.json', // Аплодисменты
      'assets/clown.json', // Клоун
      'assets/cold-face.json', // Холодное лицо
      'assets/collision.json', // Столкновение
      'assets/confetti-ball.json', // Конфетти
      'assets/cross-mark.json', // Крестик
      'assets/crossed-fingers.json', // Скрёщенные пальцы
      'assets/crystal-ball.json', // Хрустальный шар
      'assets/cursing.json', // Ругательство
      'assets/die.json', // Игральная кость
      'assets/dizy-dace.json', // Головокружение
      'assets/drool.json', // Слюни
      'assets/exclamation.json', // Восклицательный знак
      'assets/eyes.json', // Глаза
      'assets/fire.json', // Огонь
      'assets/folded-hands.json', // Сложенные руки
      'assets/gear.json', // Шестерёнка
      'assets/light-bulb.json', // Лампочка
      'assets/money-wings.json', // Деньги с крыльями
      'assets/mouth-none.json', // Лицо без рта
      'assets/muscle.json', // Мускулы
      'assets/party-popper.json', // Хлопушка
      'assets/pencil.json', // Карандаш
      'assets/pig.json', // Свинья
      'assets/poop.json', // Какашка
      'assets/question.json', // Вопросительный знак
      'assets/rainbow.json', // Радуга
      'assets/revolving-heart.json', // Вращающееся сердце
      'assets/salute.json', // Салют
      'assets/slot-machine.json', // Игровой автомат
      'assets/soccer-bal.json', // Футбольный мяч
      'assets/sparkles.json', // Блёстки
      'assets/thumbs-down.json', // Большой палец вниз
      'assets/thumbs-up.json', // Большой палец вверх
      'assets/victory.json', // Победа
      'assets/wave.json', // Волна
    ],
  };

  final Map<String, List<String>> emojiCategories = {
    'Смайлики': [
      '😊',
      '😂',
      '😍',
      '😎',
      '😢',
      '😡',
      '😱',
      '😴',
      '😇',
      '😋',
      '😜',
      '😘',
      '🤔',
      '🤗',
      '😷',
      '🤒',
      '🤕',
      '🤠',
      '🥳',
      '🥺',
      '😳',
      '😭',
      '😤',
      '😨',
      '😰',
      '😓',
      '🤤',
      '😈',
      '👻',
      '💀',
      '👽',
      '🤖',
      '🎃',
      '😺',
      '😸',
      '😹',
      '😻',
      '😼',
      '😽',
      '🙀',
    ],
    'Животные': [
      '🐶',
      '🐱',
      '🐭',
      '🐹',
      '🐰',
      '🦊',
      '🐻',
      '🐼',
      '🐨',
      '🐯',
      '🦁',
      '🐮',
      '🐷',
      '🐸',
      '🐵'
    ],
    'Еда': [
      '🍏',
      '🍎',
      '🍐',
      '🍊',
      '🍋',
      '🍌',
      '🍉',
      '🍇',
      '🍓',
      '🍈',
      '🍒',
      '🍑',
      '🥭',
      '🍍',
      '🥥'
    ],
    'Транспорт': [
      '🚗',
      '🚕',
      '🚙',
      '🚌',
      '🚎',
      '🏎',
      '🚓',
      '🚑',
      '🚒',
      '🚐',
      '🚚',
      '🚛',
      '🚜',
      '🛴',
      '🚲'
    ],
    'Спорт': [
      '⚽',
      '🏀',
      '🏈',
      '⚾',
      '🎾',
      '🏐',
      '🏉',
      '🎱',
      '🏓',
      '🏸',
      '🏒',
      '🏑',
      '🥍',
      '🏏',
      '🥊'
    ],
    'Природа': [
      '🌳',
      '🌴',
      '🌵',
      '🌾',
      '🌿',
      '☘️',
      '🍀',
      '🍁',
      '🍂',
      '🍃',
      '🌺',
      '🌻',
      '🌼',
      '🌸',
      '🌹'
    ],
    'Погода': [
      '☀️',
      '🌤',
      '⛅',
      '🌥',
      '☁️',
      '🌦',
      '🌧',
      '⛈',
      '🌩',
      '🌨',
      '❄️',
      '🌪',
      '🌫',
      '🌬',
      '🌈'
    ],
    'Символы': [
      '❤️',
      '💛',
      '💚',
      '💙',
      '💜',
      '🖤',
      '🤍',
      '🤎',
      '💔',
      '❣️',
      '💕',
      '💞',
      '💓',
      '💗',
      '💖'
    ],
    'Флаги': [
      '🇷🇺',
      '🇺🇸',
      '🇬🇧',
      '🇩🇪',
      '🇫🇷',
      '🇨🇳',
      '🇯🇵',
      '🇰🇷',
      '🇮🇳',
      '🇧🇷',
      '🇨🇦',
      '🇦🇺',
      '🇪🇸',
      '🇮🇹',
      '🇿🇦'
    ],
    'Объекты': [
      '⌚',
      '📱',
      '💻',
      '🖥',
      '🖨',
      '🖱',
      '🖲',
      '🎮',
      '🕹',
      '📷',
      '🎥',
      '📺',
      '📻',
      '🔦',
      '💡'
    ],
    'ЩЩ': [],
  };

  final Map<String, IconData> emojiCategoryIcons = {
    'Смайлики': Icons.emoji_emotions_outlined,
    'Животные': Icons.pets_outlined,
    'Еда': Icons.fastfood_outlined,
    'Транспорт': Icons.directions_car_outlined,
    'Спорт': Icons.sports_soccer_outlined,
    'Природа': Icons.nature_outlined,
    'Погода': Icons.wb_sunny_outlined,
    'Символы': Icons.favorite_outlined,
    'Флаги': Icons.flag_outlined,
    'Объекты': Icons.phone_iphone_outlined,
  };

  void _pickImage() async {
    if (widget.chatId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Чат еще не создан. Отправьте текстовое сообщение, чтобы начать чат.'),
        ),
      );
      return;
    }

    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final File file = File(image.path);
      if (file.lengthSync() <= 20 * 1024 * 1024) {
        _showPhotoEditor(file);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Файл слишком большой. Максимальный размер 20 МБ.'),
          ),
        );
      }
    }
  }

  void _showPhotoEditor(File imageFile) {
    if (widget.chatId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Чат еще не создан. Отправьте текстовое сообщение, чтобы начать чат.'),
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => PhotoEditorScreen(
          chatId: widget.chatId!, // Теперь chatId точно не null
          imageFile: imageFile,
          onSendPhoto: (photoUrl) {
            widget.onSendPhoto(photoUrl);
            _sendTypingStatus(false);
            try {
              Navigator.pop(context);
            } catch (e) {
              print(e);
            }
          },
        ),
      ),
    );
  }

  void _toggleEmojiPicker() {
    setState(() {
      _showEmojiPicker = !_showEmojiPicker;
      if (_showEmojiPicker) {
        _focusNode.unfocus(); // Скрываем клавиатуру
      } else {
        _focusNode.requestFocus(); // Показываем клавиатуру
      }
    });
  }

  void _onEmojiSelected(String emoji) {
    _controller.text += emoji;
  }

  void _sendVoiceMessage() {
    // Implement voice message functionality here
  }

  void _applyStyle(String tag) {
    final selection = _controller.selection;
    final selectedText = selection.textInside(_controller.text);
    var newText = "";
    if (tag == "```") {
      newText = '$tag$selectedText$tag';
    } else {
      newText = '<$tag>$selectedText<$tag>';
    }

    _controller.text = _controller.text.replaceRange(
      selection.start,
      selection.end,
      newText,
    );

    // Обновляем позицию курсора
    _controller.selection =
        TextSelection.collapsed(offset: selection.start + newText.length);
  }

  @override
  Widget build(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    return Container(
      color: colors.backgroundColor,
      child: Column(
        children: [
          // Отображение редактируемого сообщения
          ValueListenableBuilder<Message?>(
            valueListenable: ChatStateManager.instance.editingMessageNotifier,
            builder: (context, editingMessage, _) {
              if (editingMessage != null) {
                return Container(
                  constraints: BoxConstraints(
                    maxWidth: MediaQuery.of(context).size.width * 0.75,
                  ),
                  decoration: BoxDecoration(
                    color: colors.cardColor,
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  padding: const EdgeInsets.all(8.0),
                  margin: const EdgeInsets.symmetric(
                      horizontal: 8.0, vertical: 4.0),
                  child: IntrinsicWidth(
                    child: Row(
                      children: [
                        Icon(Icons.edit, size: 16, color: colors.iconColor),
                        SizedBox(width: 8),
                        Expanded(
                          child: RichText(
                            text: TextSpan(
                              children: _formatMessageContent(
                                editingMessage.content,
                                editingMessage.senderId,
                                widget.userId,
                              ),
                              style: TextStyle(
                                fontSize: 12.0,
                                color: colors.textColor,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 8),
                        GestureDetector(
                          onTap: _cancelEditing,
                          child: Icon(
                            Icons.close,
                            size: 16,
                            color: colors.textColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),
// Отображение сообщения, на которое отвечают
          ValueListenableBuilder<Message?>(
            valueListenable: widget.replyMessageNotifier,
            builder: (context, replyMessage, _) {
              if (replyMessage != null) {
                final bool isPhoto = isPhotoUrl(replyMessage.content);
                final bool isLottie =
                    replyMessage.content.startsWith('::animation_emoji/');

                return Center(
                  child: Container(
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.75,
                    ),
                    decoration: BoxDecoration(
                      color: colors.cardColor,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    padding: const EdgeInsets.all(8.0),
                    margin: const EdgeInsets.symmetric(
                        horizontal: 8.0, vertical: 4.0),
                    child: IntrinsicWidth(
                      child: Row(
                        children: [
                          Expanded(
                            child: isPhoto
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: Image.network(
                                      replyMessage.content,
                                      fit: BoxFit.cover,
                                      width: 100,
                                      height: 100,
                                      loadingBuilder:
                                          (context, child, loadingProgress) {
                                        if (loadingProgress == null)
                                          return child;
                                        return Center(
                                          child: CircularProgressIndicator(
                                            value: loadingProgress
                                                        .expectedTotalBytes !=
                                                    null
                                                ? loadingProgress
                                                        .cumulativeBytesLoaded /
                                                    loadingProgress
                                                        .expectedTotalBytes!
                                                : null,
                                          ),
                                        );
                                      },
                                      errorBuilder:
                                          (context, error, stackTrace) {
                                        return const Icon(Icons.error);
                                      },
                                    ),
                                  )
                                : isLottie
                                    ? Lottie.asset(
                                        replyMessage.content
                                            .replaceFirst(
                                                '::animation_emoji/', '')
                                            .replaceAll('::', ''),
                                        width: 100,
                                        height: 100,
                                        fit: BoxFit.cover,
                                      )
                                    : RichText(
                                        text: TextSpan(
                                          children: _formatMessageContent(
                                            replyMessage.content,
                                            replyMessage.senderId,
                                            widget.userId,
                                          ),
                                          style: TextStyle(
                                            fontSize: 12.0,
                                            color: colors.textColor,
                                          ),
                                        ),
                                      ),
                          ),
                          const SizedBox(width: 8),
                          GestureDetector(
                            onTap: () {
                              widget.replyMessageNotifier.value = null;
                            },
                            child: Icon(
                              Icons.close,
                              size: 16,
                              color: colors.textColor,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.emoji_emotions, color: colors.iconColor),
                  onPressed: _toggleEmojiPicker,
                ),
                Expanded(
                  child: ValueListenableBuilder<Message?>(
                    valueListenable:
                        ChatStateManager.instance.editingMessageNotifier,
                    builder: (context, editingMessage, _) {
                      if (editingMessage != null) {
                        _controller.text = editingMessage.content;
                        _controller.selection = TextSelection.fromPosition(
                          TextPosition(offset: _controller.text.length),
                        );
                      } else {
                        // _controller.clear();
                      }

                      return TextField(
                        style: TextStyle(color: colors.textColor),
                        controller: _controller,
                        focusNode: _focusNode,
                        contextMenuBuilder:
                            (context, EditableTextState editableTextState) {
                          final List<ContextMenuButtonItem> buttonItems = [];

                          if (editableTextState
                              .textEditingValue.selection.isCollapsed) {
                            // Если текст не выделен, показываем стандартное меню
                            return AdaptiveTextSelectionToolbar.buttonItems(
                              anchors: editableTextState.contextMenuAnchors,
                              buttonItems: [
                                ContextMenuButtonItem(
                                  onPressed: () => editableTextState
                                      .pasteText(SelectionChangedCause.toolbar),
                                  label: 'Вставить',
                                ),
                                ContextMenuButtonItem(
                                  onPressed: () => editableTextState
                                      .selectAll(SelectionChangedCause.toolbar),
                                  label: 'Выделить всё',
                                ),
                              ],
                            );
                          } else {
                            // Если текст выделен, показываем пользовательское меню
                            buttonItems.addAll([
                              ContextMenuButtonItem(
                                onPressed: () =>
                                    editableTextState.copySelection(
                                        SelectionChangedCause.toolbar),
                                label: 'Копировать',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => editableTextState.cutSelection(
                                    SelectionChangedCause.toolbar),
                                label: 'Вырезать',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => editableTextState
                                    .pasteText(SelectionChangedCause.toolbar),
                                label: 'Вставить',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => editableTextState
                                    .selectAll(SelectionChangedCause.toolbar),
                                label: 'Выделить всё',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => _applyStyle('b'),
                                label: 'Жирный',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => _applyStyle('i'),
                                label: 'Курсив',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => _applyStyle('u'),
                                label: 'Подчеркнутый',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => _applyStyle('del'),
                                label: 'Зачеркнутый',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => _applyStyle('mark'),
                                label: 'Выделить',
                              ),
                              ContextMenuButtonItem(
                                onPressed: () => _applyStyle("```"),
                                label: 'Код',
                              ),
                            ]);

                            return AdaptiveTextSelectionToolbar.buttonItems(
                              buttonItems: buttonItems,
                              anchors: editableTextState.contextMenuAnchors,
                            );
                          }
                        },
                        maxLines: null,
                        onChanged: (text) {
                          _startTypingTimer();
                          if (text.length > 2000) {
                            _controller.text = text.substring(0, 2000);
                            _controller.selection = TextSelection.fromPosition(
                              TextPosition(offset: _controller.text.length),
                            );
                          }
                        },
                        onSubmitted: (text) {
                          if (Platform.isWindows || !_isShiftPressed) {
                            if (ChatStateManager
                                    .instance.editingMessageNotifier.value !=
                                null) {
                              _sendEditedMessage();
                            } else {
                              _sendMessage();
                            }
                          }
                        },
                        decoration: InputDecoration(
                          hintText: 'Сообщение',
                          hintStyle: TextStyle(color: colors.hintColor),
                          filled: true,
                          fillColor: colors.cardColor,
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 8.0),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20.0),
                            borderSide: BorderSide.none, // Убираем обводку
                          ),
                        ),
                      );
                    },
                  ),
                ),
                ValueListenableBuilder<bool>(
                  valueListenable: _hasTextNotifier,
                  builder: (context, hasText, _) {
                    if (hasText) {
                      return IconButton(
                        icon: Icon(Icons.send, color: colors.iconColor),
                        onPressed: () {
                          if (ChatStateManager
                                  .instance.editingMessageNotifier.value !=
                              null) {
                            _sendEditedMessage();
                          } else {
                            _sendMessage();
                          }
                        },
                      );
                    } else {
                      return Row(
                        children: [
                          IconButton(
                            icon: Icon(Icons.attach_file,
                                color: colors.iconColor),
                            onPressed: _pickImage,
                          ),
                          IconButton(
                            icon: Icon(Icons.mic, color: colors.iconColor),
                            onPressed: _sendVoiceMessage,
                          ),
                        ],
                      );
                    }
                  },
                ),
              ],
            ),
          ),
          // Emoji picker
          if (_showEmojiPicker)
            Container(
              height: 250,
              child: DefaultTabController(
                length: emojiCategories.length + animatedEmojiCategories.length,
                child: Column(
                  children: [
                    TabBar(
                      isScrollable: true,
                      labelColor: colors.primaryColor,
                      unselectedLabelColor: colors.textColor,
                      tabs: [
                        ...emojiCategories.keys.map((String category) {
                          return Tab(
                            icon: Icon(
                              emojiCategoryIcons[category],
                              size: 20,
                            ),
                          );
                        }).toList(),
                        ...animatedEmojiCategories.keys.map((String category) {
                          return Tab(
                            icon: Icon(
                              Icons.animation_outlined,
                              size: 20,
                            ),
                          );
                        }).toList(),
                      ],
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          ...emojiCategories.values.map((List<String> emojis) {
                            return GridView.builder(
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 8,
                                childAspectRatio: 1.0,
                              ),
                              itemCount: emojis.length,
                              itemBuilder: (context, index) {
                                return GestureDetector(
                                  onTap: () {
                                    _onEmojiSelected(emojis[index]);
                                  },
                                  child: Center(
                                    child: Text(
                                      emojis[index],
                                      style: TextStyle(fontSize: 20),
                                    ),
                                  ),
                                );
                              },
                            );
                          }).toList(),
                          ...animatedEmojiCategories.values
                              .map((List<String> emojis) {
                            return GridView.builder(
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 4,
                                childAspectRatio: 1.0,
                              ),
                              itemCount: emojis.length,
                              itemBuilder: (context, index) {
                                return GestureDetector(
                                  onTap: () {
                                    _onAnimatedEmojiSelected(emojis[index]);
                                  },
                                  child: Center(
                                    child: Lottie.asset(
                                      emojis[index],
                                      width: 40,
                                      height: 40,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                );
                              },
                            );
                          }).toList(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _onAnimatedEmojiSelected(String emojiPath) {
    widget.onSend('::animation_emoji/$emojiPath');
  }

  List<TextSpan> _formatMessageContent(
      String content, String senderId, String userId) {
    final RegExp urlRegExp = RegExp(r'https?://[^\s]+');
    final RegExp codeBlockRegex =
        RegExp(r'```(\w+)?\s*([\s\S]+?)```', dotAll: true);
    final RegExp tagRegex = RegExp(r'<(/?[^>]+)>');

    content = content.replaceAll(codeBlockRegex, '');

    final Iterable<Match> matches = urlRegExp.allMatches(content);
    List<TextSpan> textSpans = [];
    int lastIndex = 0;

    if (senderId == userId) {
      textSpans.add(TextSpan(
        text: 'Вы: ',
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.blue,
        ),
      ));
    }

    for (Match match in matches) {
      if (lastIndex < match.start) {
        final String textPart = content.substring(lastIndex, match.start);
        textSpans.addAll(_parseTextContent(textPart));
      }
      textSpans.add(
        TextSpan(
          text: 'фотография',
          style: TextStyle(
            color: Colors.lightBlue,
            fontStyle: FontStyle.italic,
          ),
        ),
      );
      lastIndex = match.end;
    }

    if (lastIndex < content.length) {
      final String remainingText = content.substring(lastIndex);
      textSpans.addAll(_parseTextContent(remainingText));
    }

    return textSpans;
  }

  List<TextSpan> _parseTextContent(String content) {
    final List<TextSpan> spans = [];
    final RegExp tagRegex = RegExp(r'<(/?[^>]+)>');
    final List<String> parts = content.split(tagRegex);
    final List<RegExpMatch> matches = tagRegex.allMatches(content).toList();

    for (int i = 0; i < parts.length; i++) {
      if (i < matches.length) {
        final String tag = matches[i].group(0)!;
        if (tag == '<b>' || tag == '<strong>') {
          spans.add(TextSpan(
              text: parts[i], style: TextStyle(fontWeight: FontWeight.bold)));
        } else if (tag == '</b>' || tag == '</strong>') {
          spans.add(TextSpan(text: parts[i]));
        } else if (tag == '<i>' || tag == '<em>') {
          spans.add(TextSpan(
              text: parts[i], style: TextStyle(fontStyle: FontStyle.italic)));
        } else if (tag == '</i>' || tag == '</em>') {
          spans.add(TextSpan(text: parts[i]));
        } else if (tag == '<del>' || tag == '<s>') {
          spans.add(TextSpan(
              text: parts[i],
              style: TextStyle(decoration: TextDecoration.lineThrough)));
        } else if (tag == '</del>' || tag == '</s>') {
          spans.add(TextSpan(text: parts[i]));
        } else if (tag == '<u>') {
          spans.add(TextSpan(
              text: parts[i],
              style: TextStyle(decoration: TextDecoration.underline)));
        } else if (tag == '</u>') {
          spans.add(TextSpan(text: parts[i]));
        } else if (tag == '<small>') {
          spans.add(TextSpan(text: parts[i], style: TextStyle(fontSize: 10)));
        } else if (tag == '</small>') {
          spans.add(TextSpan(text: parts[i]));
        } else if (tag == '<sub>') {
          spans.add(TextSpan(
              text: parts[i],
              style: TextStyle(fontFeatures: [FontFeature.subscripts()])));
        } else if (tag == '</sub>') {
          spans.add(TextSpan(text: parts[i]));
        } else if (tag == '<sup>') {
          spans.add(TextSpan(
              text: parts[i],
              style: TextStyle(fontFeatures: [FontFeature.superscripts()])));
        } else if (tag == '</sup>') {
          spans.add(TextSpan(text: parts[i]));
        } else if (tag == '<ins>') {
          spans.add(TextSpan(
              text: parts[i],
              style: TextStyle(decoration: TextDecoration.underline)));
        } else if (tag == '</ins>') {
          spans.add(TextSpan(text: parts[i]));
        } else if (tag == '<mark>') {
          spans.add(TextSpan(
              text: parts[i],
              style: TextStyle(backgroundColor: Colors.yellow)));
        } else if (tag == '</mark>') {
          spans.add(TextSpan(text: parts[i]));
        } else {
          spans.add(TextSpan(text: parts[i]));
        }
      } else {
        spans.add(TextSpan(text: parts[i]));
      }
    }

    return spans;
  }
}
