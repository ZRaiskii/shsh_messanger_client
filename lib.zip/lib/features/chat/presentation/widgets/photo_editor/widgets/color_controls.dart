import 'package:flutter/material.dart';

class ColorControls extends StatelessWidget {
  final double brightness;
  final double contrast;
  final double exposure;
  final double saturation;
  final double highlights;
  final double shadows;
  final Function(double) onBrightnessChanged;
  final Function(double) onContrastChanged;
  final Function(double) onExposureChanged;
  final Function(double) onSaturationChanged;
  final Function(double) onHighlightsChanged;
  final Function(double) onShadowsChanged;

  const ColorControls({
    required this.brightness,
    required this.contrast,
    required this.exposure,
    required this.saturation,
    required this.highlights,
    required this.shadows,
    required this.onBrightnessChanged,
    required this.onContrastChanged,
    required this.onExposureChanged,
    required this.onSaturationChanged,
    required this.onHighlightsChanged,
    required this.onShadowsChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildSlider('Яркость', brightness, -1.0, 1.0, onBrightnessChanged),
        _buildSlider('Контраст', contrast, 0.0, 2.0, onContrastChanged),
        _buildSlider('Экспозиция', exposure, -1.0, 1.0, onExposureChanged),
        _buildSlider('Насыщенность', saturation, 0.0, 2.0, onSaturationChanged),
        _buildSlider('Света', highlights, -1.0, 1.0, onHighlightsChanged),
        _buildSlider('Тени', shadows, -1.0, 1.0, onShadowsChanged),
      ],
    );
  }

  Widget _buildSlider(String label, double value, double min, double max,
      Function(double) onChanged) {
    return Column(
      children: [
        Text('$label: ${value.toStringAsFixed(2)}'),
        Slider(
          value: value,
          min: min,
          max: max,
          onChanged: onChanged,
        ),
      ],
    );
  }
}
