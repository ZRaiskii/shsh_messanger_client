import 'dart:ui';
import 'package:flutter/material.dart';

class DrawingPainter extends CustomPainter {
  final List<List<Offset?>> pointsList;
  final Color color;
  final double strokeWidth;

  DrawingPainter(this.pointsList, this.color, this.strokeWidth);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeCap = StrokeCap.round
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    for (var points in pointsList) {
      for (int i = 0; i < points.length - 1; i++) {
        if (points[i] != null && points[i + 1] != null) {
          canvas.drawLine(points[i]!, points[i + 1]!, paint);
        } else if (points[i] != null && points[i + 1] == null) {
          canvas.drawPoints(PointMode.points, [points[i]!], paint);
        }
      }
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
