import 'package:flutter/material.dart';

class TextEditorDialog extends StatelessWidget {
  final TextEditingController textController;
  final Function(String) onTextApplied;

  const TextEditorDialog({
    required this.textController,
    required this.onTextApplied,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Добавить текст'),
      content: TextField(
        controller: textController,
        decoration: InputDecoration(hintText: 'Введите текст'),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
            onTextApplied(textController.text);
          },
          child: Text('Добавить'),
        ),
      ],
    );
  }
}
