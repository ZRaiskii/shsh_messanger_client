import 'package:flutter/material.dart';

class EmojiPicker extends StatelessWidget {
  final Function(String) onEmojiSelected;
  final Function(String) onAnimatedEmojiSelected;

  const EmojiPicker({
    required this.onEmojiSelected,
    required this.onAnimatedEmojiSelected,
  });

  @override
  Widget build(BuildContext context) {
    final emojiCategories = {
      'Smileys & Emotion': ['😀', '😂', '😊', '😒'],
      'Animals & Nature': ['🐶', '🦁', '🐯', '🦄'],
    };

    final animatedEmojiCategories = {
      'Animated': ['animated1.json', 'animated2.json'],
    };

    return Container(
      height: 250,
      child: DefaultTabController(
        length: emojiCategories.length + animatedEmojiCategories.length,
        child: Column(
          children: [
            TabBar(
              isScrollable: true,
              tabs: [
                ...emojiCategories.keys.map((category) {
                  return Tab(text: category);
                }).toList(),
                ...animatedEmojiCategories.keys.map((category) {
                  return Tab(text: category);
                }).toList(),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: [
                  ...emojiCategories.values.map((emojis) {
                    return GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 8,
                        childAspectRatio: 1.0,
                      ),
                      itemCount: emojis.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () => onEmojiSelected(emojis[index]),
                          child: Center(
                            child: Text(
                              emojis[index],
                              style: TextStyle(fontSize: 20),
                            ),
                          ),
                        );
                      },
                    );
                  }).toList(),
                  ...animatedEmojiCategories.values.map((emojis) {
                    return GridView.builder(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        childAspectRatio: 1.0,
                      ),
                      itemCount: emojis.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () => onAnimatedEmojiSelected(emojis[index]),
                          child: Center(
                            child: Text(
                              'Animated $index',
                              style: TextStyle(fontSize: 20),
                            ),
                          ),
                        );
                      },
                    );
                  }).toList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
