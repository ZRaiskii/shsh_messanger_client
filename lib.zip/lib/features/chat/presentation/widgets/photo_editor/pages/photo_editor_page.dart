import 'dart:async';
import 'dart:convert';
import 'dart:ui' as ui; // Import the ui package for Image
import 'package:flutter/services.dart'; // Import for ByteData
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:photo_view/photo_view.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image/image.dart' as img;
import 'dart:typed_data';
import 'dart:io';

import 'package:shared_preferences/shared_preferences.dart';
import '../../../../../../core/utils/constants.dart';
import '../../../../../auth/data/models/user_model.dart';
import '../widgets/color_picker_button.dart';
import '../widgets/drawing_painter.dart';

class PhotoEditorScreen extends StatefulWidget {
  final File imageFile;
  final String chatId;
  final Function(String) onSendPhoto;

  const PhotoEditorScreen({
    required this.imageFile,
    required this.chatId,
    required this.onSendPhoto,
    super.key,
  });

  @override
  _PhotoEditorScreenState createState() => _PhotoEditorScreenState();
}

class _PhotoEditorScreenState extends State<PhotoEditorScreen> {
  Uint8List? _imageBytes;
  Uint8List? _originalBytes;
  double _brightness = 1.0;
  double _contrast = 1.0;
  double _saturation = 1.0;
  double _blurRadius = 0.0;
  final List<Uint8List> _history = [];
  int _historyIndex = -1;
  bool _isLoading = true;
  bool _isMenuVisible = false;
  bool _isSending = false;
  Timer? _filterTimer;
  List<Offset?> points = [];
  bool _isDrawing = false;
  bool _isDrawingMode = false;
  Color _drawingColor = Colors.red;
  double _strokeWidth = 5.0;
  List<List<Offset?>> _drawingSessions = [];
  List<Offset?> _currentSessionPoints = [];
  Color _currentSessionColor = Colors.red;
  double _currentSessionStrokeWidth = 5.0;

  @override
  void initState() {
    super.initState();
    _loadImage();
  }

  Future<void> _loadImage() async {
    try {
      _originalBytes = await widget.imageFile.readAsBytes();
      setState(() {
        _imageBytes = _originalBytes;
        _history.add(_originalBytes!);
        _historyIndex = 0;
        _isLoading = false;
      });
    } catch (e) {
      print("Ошибка загрузки изображения: $e");
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _addToHistory(Uint8List newImageBytes) {
    if (_historyIndex < _history.length - 1) {
      _history.removeRange(_historyIndex + 1, _history.length);
    }
    _history.add(newImageBytes);
    _historyIndex = _history.length - 1;
  }

  void _endDrawing() {
    setState(() {
      _isDrawing = false;
      points.add(null);
      _addToHistory(_imageBytes!);
    });
  }

  void _startDrawingSession() {
    // setState(() {
    //   _currentSessionPoints = [];
    //   _drawingSessions.add(_currentSessionPoints);
    // });
  }

  void _endDrawingSession() {
    // setState(() {
    //   _currentSessionPoints.add(null); // End the current line
    //   _applyDrawingsToImage();
    //   _addToHistory(_imageBytes!); // Save the current state
    // });
  }

  Future<void> _applyDrawingsToImage() async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final paint = Paint()
      ..color = _currentSessionColor
      ..strokeCap = StrokeCap.round
      ..strokeWidth = _currentSessionStrokeWidth
      ..style = PaintingStyle.stroke;

    // Draw the original image
    final ui.Image image = await decodeImageFromList(_imageBytes!);
    canvas.drawImage(image, Offset.zero, paint);

    // Draw the lines
    for (var session in _drawingSessions) {
      for (int i = 0; i < session.length - 1; i++) {
        if (session[i] != null && session[i + 1] != null) {
          canvas.drawLine(session[i]!, session[i + 1]!, paint);
        }
      }
    }

    final picture = recorder.endRecording();
    final ui.Image editedImage = await picture.toImage(
      image.width,
      image.height,
    );

    final ByteData? byteData =
        await editedImage.toByteData(format: ui.ImageByteFormat.png);
    final Uint8List editedBytes = byteData!.buffer.asUint8List();

    setState(() {
      _imageBytes = editedBytes;
      _addToHistory(editedBytes);
    });
  }

  void _undo() {
    if (_historyIndex > 0) {
      setState(() {
        _historyIndex--;
        _imageBytes = _history[_historyIndex];
      });
    }
  }

  void _redo() {
    if (_historyIndex < _history.length - 1) {
      setState(() {
        _historyIndex++;
        _imageBytes = _history[_historyIndex];
      });
    }
  }

  void _adjustBrightness(double brightness) {
    setState(() => _brightness = brightness);
    _scheduleFilterUpdate();
  }

  void _adjustContrast(double contrast) {
    setState(() => _contrast = contrast);
    _scheduleFilterUpdate();
  }

  void _adjustSaturation(double saturation) {
    setState(() => _saturation = saturation);
    _scheduleFilterUpdate();
  }

  void _scheduleFilterUpdate() {
    _filterTimer?.cancel();
    _filterTimer = Timer(const Duration(milliseconds: 100), _applyFilters);
  }

  void _toggleMenu() {
    setState(() {
      _isMenuVisible = !_isMenuVisible;
    });
  }

  Future<void> _cropImage([CropAspectRatio? aspectRatio]) async {
    final CroppedFile? croppedFile = await ImageCropper().cropImage(
      sourcePath: widget.imageFile.path,
      aspectRatio: aspectRatio,
    );

    if (croppedFile != null) {
      final Uint8List croppedImageBytes = await croppedFile.readAsBytes();
      setState(() {
        _imageBytes = croppedImageBytes;
        _addToHistory(croppedImageBytes);
      });
    }
  }

  Future<void> _saveEditedImage() async {
    if (_imageBytes == null) return;

    setState(() {
      _isSending = true;
    });

    // Применяем фильтры к изображению
    final Uint8List finalImageBytes = await compute(
      _applyFiltersSync,
      {
        'originalBytes': _originalBytes!,
        'brightness': _brightness,
        'contrast': _contrast,
        'saturation': _saturation,
      },
    );

    // Создаем временный файл с расширением .png
    final String tempFilePath =
        widget.imageFile.path.replaceAll(RegExp(r'\.png_temp$'), '.png');
    final File tempFile = File(tempFilePath);
    await tempFile.writeAsBytes(finalImageBytes);

    try {
      // Загружаем фото на сервер
      final String? photoUrl = await _uploadPhoto(tempFile);

      if (photoUrl != null) {
        // Передаем URL загруженного фото в коллбэк
        widget.onSendPhoto(photoUrl);
      }
    } catch (e) {
      print("Ошибка при загрузке фото: $e");
    } finally {
      // Удаляем временный файл после загрузки
      await tempFile.delete();
      setState(() {
        _isSending = false;
      });
    }
  }

  Future<String?> _uploadPhoto(File file) async {
    final prefs = await SharedPreferences.getInstance();
    final cachedUser = prefs.getString('cached_user');
    if (cachedUser != null) {
      final token =
          UserModel.fromJson(json.decode(cachedUser) as Map<String, dynamic>)
              .token;
      if (token != null && token.isNotEmpty) {
        final uri = Uri.parse(
            '${Constants.baseUrl}${Constants.uploadPhotoEndpoint}${widget.chatId}');
        final request = http.MultipartRequest('POST', uri);
        request.fields['chatId'] = widget.chatId;
        request.headers['Authorization'] = 'Bearer $token';
        request.files.add(await http.MultipartFile.fromPath('file', file.path));

        final response = await request.send();
        if (response.statusCode == 200) {
          final responseBody = await response.stream.bytesToString();
          final jsonResponse = json.decode(responseBody);
          return jsonResponse['fileUrl'];
        } else {
          print('Ошибка при загрузке файла: ${response.statusCode}');
          return null;
        }
      } else {
        print('Токен отсутствует или пуст');
        return null;
      }
    } else {
      print('Кэшированный пользователь недоступен');
      return null;
    }
  }

  Future<void> _applyFilters() async {
    if (_originalBytes == null) return;

    final Uint8List filteredImageBytes = await Future(() {
      final img.Image? image = img.decodeImage(_originalBytes!);
      if (image == null) return _originalBytes!;

      img.Image editedImage = img.adjustColor(
        image,
        brightness: _brightness,
        contrast: _contrast,
        saturation: _saturation,
      );

      return img.encodePng(editedImage);
    });

    if (!mounted) return;
    setState(() => _imageBytes = filteredImageBytes);
  }

  static Uint8List _applyFiltersSync(Map<String, dynamic> params) {
    final Uint8List originalBytes = params['originalBytes'];
    final double brightness = params['brightness'];
    final double contrast = params['contrast'];
    final double saturation = params['saturation'];

    final img.Image? image = img.decodeImage(originalBytes);
    if (image == null) return originalBytes;

    img.Image editedImage = img.adjustColor(
      image,
      brightness: brightness,
      contrast: contrast,
      saturation: saturation,
    );
    return img.encodePng(editedImage);
  }

  static Uint8List applyPresetFilter(
      Uint8List originalBytes, String filterName) {
    final img.Image? image = img.decodeImage(originalBytes);
    if (image == null) return originalBytes;

    switch (filterName) {
      case 'sepia':
        return img.encodePng(img.adjustColor(image, gamma: 2));
      case 'grayscale':
        return img.encodePng(img.grayscale(image));
      case 'vintage':
        return img.encodePng(img.adjustColor(image,
            brightness: 0.9, contrast: 1.2, saturation: 0.7));
      default:
        return originalBytes;
    }
  }

  void _applyFilter(String filterName) {
    if (_imageBytes == null) return;
    final filteredBytes = applyPresetFilter(_imageBytes!, filterName);
    setState(() {
      _imageBytes = filteredBytes;
      _addToHistory(filteredBytes);
    });
  }

  void _rotateImage(double angle) {
    if (_imageBytes == null) return;

    final img.Image? image = img.decodeImage(_imageBytes!);
    if (image == null) return;

    final rotatedImage = img.copyRotate(image, angle: angle);
    final rotatedBytes = img.encodePng(rotatedImage);

    setState(() {
      _imageBytes = rotatedBytes;
      _addToHistory(rotatedBytes);
    });
  }

  void _flipImage({bool horizontal = false, bool vertical = false}) {
    // if (_imageBytes == null) return;

    // final img.Image? image = img.decodeImage(_imageBytes!);
    // if (image == null) return;

    // final flippedImage = img.flip(image, horizontal: horizontal, vertical: vertical);
    // final flippedBytes = img.encodePng(flippedImage);

    // setState(() {
    //   _imageBytes = flippedBytes;
    //   _addToHistory(flippedBytes);
    // });
  }

  void _applyBlur(double radius) {
    if (_imageBytes == null) return;

    final img.Image? image = img.decodeImage(_imageBytes!);
    if (image == null) return;

    final blurredImage = img.gaussianBlur(image, radius: radius.toInt());
    final blurredBytes = img.encodePng(blurredImage);

    setState(() {
      _imageBytes = blurredBytes;
      _addToHistory(blurredBytes);
    });
  }

  Future<void> _saveToGallery() async {
    // if (_imageBytes == null) return;

    // final directory = await getApplicationDocumentsDirectory();
    // final file = File('${directory.path}/edited_image.png');
    // await file.writeAsBytes(_imageBytes!);

    // await GallerySaver.saveImage(file.path);
  }

  @override
  void dispose() {
    _filterTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Редактирование фото'),
        actions: [
          IconButton(icon: const Icon(Icons.undo), onPressed: _undo),
          IconButton(icon: const Icon(Icons.redo), onPressed: _redo),
          IconButton(
            icon: _isSending
                ? const CircularProgressIndicator()
                : const Icon(Icons.send),
            onPressed: _isSending ? null : _saveEditedImage,
          ),
        ],
      ),
      body: SafeArea(
        child: Row(
          children: [
            Visibility(
              visible: _isDrawingMode,
              child: RotatedBox(
                quarterTurns: 3,
                child: Slider(
                  value: _strokeWidth,
                  min: 1.0,
                  max: 20.0,
                  onChanged: (value) {
                    setState(() {
                      _strokeWidth = value;
                    });
                  },
                ),
              ),
            ),
            Expanded(
              child: Column(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onPanStart: (details) {
                        setState(() {
                          _isDrawing = true;
                          _startDrawingSession();
                          _currentSessionPoints.add(details.localPosition);
                        });
                      },
                      onPanUpdate: (details) {
                        if (_isDrawing) {
                          setState(() {
                            _currentSessionPoints.add(details.localPosition);
                          });
                        }
                      },
                      onPanEnd: (details) {
                        setState(() {
                          _isDrawing = false;
                          _currentSessionPoints
                              .add(null); // End the current line
                          _endDrawingSession();
                        });
                      },
                      child: _isLoading
                          ? const Center(child: CircularProgressIndicator())
                          : _imageBytes != null
                              ? Stack(
                                  children: [
                                    PhotoView(
                                      key: ValueKey(_imageBytes),
                                      imageProvider: MemoryImage(_imageBytes!),
                                    ),
                                    // CustomPaint(
                                    //   painter: DrawingPainter(
                                    //       _drawingSessions,
                                    //       _currentSessionColor,
                                    //       _currentSessionStrokeWidth),
                                    // ),
                                  ],
                                )
                              : const Center(
                                  child: Text("Изображение не загружено")),
                    ),
                  ),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    height: _isMenuVisible ? 350.0 : 0.0,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          _buildSlider(
                            label: 'Яркость',
                            value: _brightness,
                            min: 0.0,
                            max: 2.0,
                            onChanged: _adjustBrightness,
                          ),
                          _buildSlider(
                            label: 'Контраст',
                            value: _contrast,
                            min: 0.0,
                            max: 2.0,
                            onChanged: _adjustContrast,
                          ),
                          _buildSlider(
                            label: 'Насыщенность',
                            value: _saturation,
                            min: 0.0,
                            max: 2.0,
                            onChanged: _adjustSaturation,
                          ),
                          _buildSlider(
                            label: 'Размытие',
                            value: _blurRadius,
                            min: 0.0,
                            max: 10.0,
                            onChanged: (value) {
                              setState(() => _blurRadius = value);
                              _applyBlur(value);
                            },
                          ),
                          Row(
                            children: [
                              FilterButton(
                                  filterName: 'Сепия',
                                  onPressed: () => _applyFilter('sepia')),
                              FilterButton(
                                  filterName: 'Ч/Б',
                                  onPressed: () => _applyFilter('grayscale')),
                              FilterButton(
                                  filterName: 'Винтаж',
                                  onPressed: () => _applyFilter('vintage')),
                            ],
                          ),
                          Row(
                            children: [
                              IconButton(
                                  icon: Icon(Icons.rotate_left),
                                  onPressed: () => _rotateImage(-90)),
                              IconButton(
                                  icon: Icon(Icons.rotate_right),
                                  onPressed: () => _rotateImage(90)),
                              IconButton(
                                  icon: Icon(Icons.flip),
                                  onPressed: () =>
                                      _flipImage(horizontal: true)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.crop),
                          onPressed: _cropImage,
                          tooltip: 'Обрезать изображение',
                        ),
                        IconButton(
                          icon: const Icon(Icons.tune),
                          onPressed: _toggleMenu,
                          tooltip: 'Настройки изображения',
                        ),
                        IconButton(
                          icon: const Icon(Icons.save),
                          onPressed: _saveToGallery,
                          tooltip: 'Сохранить в галерею',
                        ),
                        // IconButton(
                        //   icon: const Icon(Icons.brush),
                        //   onPressed: () {
                        //     setState(() {
                        //       _isDrawingMode = !_isDrawingMode;
                        //     });
                        //   },
                        //   tooltip: 'Рисовать',
                        // ),
                        // IconButton(
                        //   icon: const Icon(Icons.color_lens),
                        //   onPressed: () => _openColorPicker(context),
                        //   tooltip: 'Выбрать цвет',
                        // ),
                      ],
                    ),
                  ),
                  Container(
                    height: 100,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _history.length,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _imageBytes = _history[index];
                              _historyIndex = index;
                            });
                          },
                          child: Image.memory(_history[index]),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _openColorPicker(BuildContext context) {
    final List<Color> colors = [
      Colors.red,
      Colors.blue,
      Colors.green,
      Colors.yellow,
      Colors.orange,
      Colors.purple,
      Colors.black,
      Colors.white,
      Colors.brown,
      Colors.pink,
    ];

    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          height: 250,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Выберите цвет кисти',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Expanded(
                child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 5, // Количество столбцов
                    crossAxisSpacing: 10, // Расстояние между столбцами
                    mainAxisSpacing: 10, // Расстояние между строками
                  ),
                  itemCount: colors.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          _drawingColor =
                              colors[index]; // Устанавливаем выбранный цвет
                        });
                        Navigator.pop(context); // Закрываем модальное окно
                      },
                      child: Container(
                        decoration: BoxDecoration(
                          color: colors[index],
                          shape: BoxShape.circle, // Круглая форма для цветов
                          border: Border.all(
                            color: Colors.grey,
                            width: 1,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSlider({
    required String label,
    required double value,
    required double min,
    required double max,
    required Function(double) onChanged,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Expanded(
            child: Slider(
              value: value,
              min: min,
              max: max,
              onChanged: onChanged,
              onChangeEnd: (value) => _addToHistory(_imageBytes!),
            ),
          ),
        ],
      ),
    );
  }
}

class FilterButton extends StatelessWidget {
  final String filterName;
  final VoidCallback onPressed;

  const FilterButton({required this.filterName, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      child: Text(filterName),
    );
  }
}
