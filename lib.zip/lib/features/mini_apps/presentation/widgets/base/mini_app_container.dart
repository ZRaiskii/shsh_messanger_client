import 'package:flutter/material.dart';
import '../../../../../core/utils/AppColors.dart';
import '../../../../settings/data/services/theme_manager.dart';

class MiniAppContainer extends StatelessWidget {
  final Widget miniApp;
  final String title;
  final String info;

  MiniAppContainer({
    required this.miniApp,
    required this.title,
    required this.info,
  });

  @override
  Widget build(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
          style: TextStyle(color: colors.textColor),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: colors.iconColor),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        backgroundColor: colors.appBarColor,
        iconTheme: IconThemeData(color: colors.iconColor),
        actions: [
          IconButton(
            icon: Icon(Icons.info, color: colors.iconColor),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    title: Text('Информация'),
                    content: Text(info),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: Text('Закрыть'),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      ),
      backgroundColor: colors.backgroundColor,
      body: miniApp,
    );
  }
}
