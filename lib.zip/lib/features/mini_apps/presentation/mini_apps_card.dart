// Новый файл: mini_apps_page.dart
import 'package:flutter/material.dart';
import 'package:shsh_social/core/utils/AppColors.dart';
import 'package:shsh_social/features/mini_apps/presentation/widgets/snake_game_page.dart';
import 'package:shsh_social/features/mini_apps/presentation/widgets/custom_calendar_page.dart';

import '../../settings/data/services/theme_manager.dart';

class MiniAppCard {
  final String title;
  final String description;
  final String? image;
  final Widget page;

  MiniAppCard({
    required this.title,
    required this.description,
    this.image,
    required this.page,
  });
}

class MiniAppsPage extends StatelessWidget {
  MiniAppsPage({Key? key}) : super(key: key);

  final List<MiniAppCard> apps = [
    MiniAppCard(
      title: 'Новогодняя змейка',
      description: 'С Новым 2025 годом!',
      page: SnakeGamePage(),
    ),
    MiniAppCard(
      title: 'Календарь',
      description: 'Планируйте свои события',
      page: CustomCalendarPage(),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Мини-Приложения'),
        backgroundColor: colors.appBarColor,
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 1,
        ),
        itemCount: apps.length,
        itemBuilder: (context, index) {
          final app = apps[index];
          return Card(
            color: colors.cardColor,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => app.page),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(12),
                        ),
                        color: colors.backgroundColor,
                        image: app.image != null
                            ? DecorationImage(
                                image: NetworkImage(app.image!),
                                fit: BoxFit.cover,
                              )
                            : null,
                      ),
                      child: app.image == null
                          ? const Icon(Icons.apps, size: 50)
                          : null,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          app.title,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: colors.textColor,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          app.description,
                          style: TextStyle(
                            fontSize: 12,
                            color: colors.textColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
