import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shsh_social/features/mini_apps/presentation/widgets/wordle_mini_app/data/wordle_manager.dart';
import '../../../core/utils/AppColors.dart';
import 'widgets/snake_game_page.dart';
import 'widgets/custom_calendar_page.dart';
import 'widgets/step_counter_page.dart';
import 'widgets/clicker_game_page.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import '../../settings/data/services/theme_manager.dart';
import 'widgets/base/mini_app_container.dart';
import 'widgets/wordle_mini_app/presentation/pages/home_page.dart';

class MiniAppCard {
  final String title;
  final String description;
  final String? image;
  final Widget page;
  final List<TargetPlatform> supportedPlatforms;
  final bool isNew;
  final bool isLocked;
  final bool isUpdated;

  MiniAppCard({
    required this.title,
    required this.description,
    this.image,
    required this.page,
    this.supportedPlatforms = const [],
    this.isNew = false,
    this.isLocked = false,
    this.isUpdated = false,
  });
}

class MiniAppsPage extends StatefulWidget {
  MiniAppsPage({Key? key}) : super(key: key);

  @override
  _MiniAppsPageState createState() => _MiniAppsPageState();
}

class _MiniAppsPageState extends State<MiniAppsPage> {
  late Future<List<MiniAppCard>> appsFuture;

  @override
  void initState() {
    super.initState();
    appsFuture = _initializeApps();
  }

  Future<List<MiniAppCard>> _initializeApps() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<MiniAppCard> apps = [
      MiniAppCard(
        title: 'Новогодняя змейка',
        description: 'С Новым 2025 годом!',
        image: 'assets/mini_apps/images/snake.png',
        page: SnakeGamePage(),
        supportedPlatforms: [TargetPlatform.android, TargetPlatform.iOS],
      ),
      MiniAppCard(
        title: 'Календарь',
        description: 'Планируйте свои события',
        image: 'assets/mini_apps/images/calendar.png',
        page: CustomCalendarPage(),
        supportedPlatforms: [
          TargetPlatform.android,
          TargetPlatform.iOS,
          TargetPlatform.windows,
          TargetPlatform.macOS,
          TargetPlatform.linux
        ],
      ),
      MiniAppCard(
        title: 'Шагомер',
        description: 'Следите за количеством шагов',
        image: 'assets/mini_apps/images/step_counter.png',
        page: StepCounterPage(),
        supportedPlatforms: [TargetPlatform.android, TargetPlatform.iOS],
        isLocked: true,
      ),
      MiniAppCard(
        title: 'Кликер',
        description: 'Нажмите кнопку как можно больше раз',
        image: 'assets/mini_apps/images/clicker.png',
        page: ClickerGamePage(),
        supportedPlatforms: [TargetPlatform.android, TargetPlatform.iOS],
        isUpdated: true,
      ),
      MiniAppCard(
        title: 'Угадай слово',
        description:
            'Угадайте загаданное слово за минимальное количество попыток',
        image: 'assets/mini_apps/images/wordle.png',
        page: WordleHomePage(
          wordleManager: WordleManager(),
        ),
        supportedPlatforms: [
          TargetPlatform.android,
          TargetPlatform.iOS,
          TargetPlatform.windows,
        ],
        isNew: true,
      ),
      MiniAppCard(
        title: 'SOON',
        description: 'скоро...',
        image: null,
        page: Container(),
      ),
    ];

    // Sort apps based on click counts
    apps.sort((a, b) => _getClickCount(b.title, prefs)
        .compareTo(_getClickCount(a.title, prefs)));
    return apps;
  }

  int _getClickCount(String appTitle, SharedPreferences prefs) {
    return prefs.getInt(appTitle) ?? 0;
  }

  void _incrementClickCount(String appTitle) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int count = _getClickCount(appTitle, prefs);
    prefs.setInt(appTitle, count + 1);
    setState(() {
      appsFuture = _initializeApps(); // Refresh the list
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = isWhiteNotifier.value ? AppColors.light() : AppColors.dark();

    return Scaffold(
      backgroundColor: colors.backgroundColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          'Мини-Приложения',
          style: TextStyle(
            fontSize: 28.0,
            fontWeight: FontWeight.bold,
            color: colors.textColor,
          ),
        ),
        backgroundColor: colors.appBarColor,
      ),
      body: FutureBuilder<List<MiniAppCard>>(
        future: appsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Ошибка: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Нет доступных приложений'));
          } else {
            List<MiniAppCard> apps = snapshot.data!;
            return GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1,
              ),
              itemCount: apps.length,
              itemBuilder: (context, index) {
                final app = apps[index];
                final isSupported = app.supportedPlatforms.isEmpty ||
                    app.supportedPlatforms.contains(Theme.of(context).platform);

                return Card(
                  color: isSupported ? colors.cardColor : Colors.black12,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Stack(
                    children: [
                      InkWell(
                        borderRadius: BorderRadius.circular(12),
                        onTap: isSupported
                            ? () {
                                if (!app.isLocked) {
                                  _incrementClickCount(app.title);
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => MiniAppContainer(
                                        miniApp: app.page,
                                        title: app.title,
                                        info: app.description,
                                      ),
                                    ),
                                  );
                                }
                              }
                            : () => showDialog(
                                  context: context,
                                  builder: (context) => AlertDialog(
                                    title: const Text('Не подходит'),
                                    content: const Text(
                                        'Приложение не подходит к вашему устройству'),
                                    actions: [
                                      TextButton(
                                        onPressed: () =>
                                            Navigator.of(context).pop(),
                                        child: const Text('OK'),
                                      ),
                                    ],
                                  ),
                                ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Expanded(
                              child: Container(
                                decoration: BoxDecoration(
                                  borderRadius: const BorderRadius.vertical(
                                    top: Radius.circular(12),
                                  ),
                                  color: colors.backgroundColor,
                                  image: app.image != null
                                      ? DecorationImage(
                                          image: AssetImage(app.image!),
                                          fit: BoxFit.cover,
                                        )
                                      : null,
                                ),
                                child: app.image == null
                                    ? const Icon(Icons.apps, size: 50)
                                    : null,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    app.title,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: colors.textColor,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    app.description,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: colors.textColor,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (app.isNew)
                        Positioned(
                          top: 8,
                          left: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.red,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              'НОВИНКА',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 10,
                              ),
                            ),
                          ),
                        ),
                      if (app.isLocked)
                        Positioned(
                          bottom: 8,
                          right: 8,
                          child: Icon(
                            Icons.lock,
                            color: Colors.grey,
                          ),
                        ),
                      if (app.isUpdated)
                        Positioned(
                          top: 8,
                          right: 8,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              'ОБНОВЛЕНО',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 10,
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
