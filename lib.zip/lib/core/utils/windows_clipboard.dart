import 'dart:ffi';
import 'dart:io';
import 'dart:typed_data';
import 'package:win32/win32.dart';

typedef MemcpyFunc = Void Function(Pointer<Uint8>, Pointer<Uint8>, IntPtr);
typedef Memcpy = void Function(Pointer<Uint8>, Pointer<Uint8>, int);

final DynamicLibrary cLibrary = DynamicLibrary.open('msvcrt.dll');
final Memcpy memcpy =
    cLibrary.lookup<NativeFunction<MemcpyFunc>>('memcpy').asFunction();

class WindowsClipboard {
  static Future<Uint8List?> getImageFromClipboard() async {
    if (!Platform.isWindows) {
      return null;
    }

    try {
      if (IsClipboardFormatAvailable(CLIPBOARD_FORMAT.CF_DIB) == TRUE) {
        if (OpenClipboard(NULL) != 0) {
          final int hClip = GetClipboardData(CLIPBOARD_FORMAT.CF_DIB);
          if (hClip == NULL) {
            CloseClipboard();
            return null;
          }

          final Pointer<Void> hClipPointer = Pointer.fromAddress(hClip);
          final Pointer<NativeType> data = GlobalLock(hClipPointer);
          if (data == NULL) {
            GlobalUnlock(hClipPointer);
            CloseClipboard();
            return null;
          }

          final int size = GlobalSize(hClipPointer);
          final imageBytes = Uint8List(size);
          final Pointer<Uint8> ptr =
              Pointer<Uint8>.fromAddress(imageBytes.length);

          // Используем memcpy для копирования данных
          memcpy(ptr, Pointer<Uint8>.fromAddress(data.address), size);

          GlobalUnlock(hClipPointer);
          CloseClipboard();
          return imageBytes;
        }
      }
    } catch (e) {
      print('Ошибка при получении изображения из буфера обмена: $e');
    } finally {
      CloseClipboard();
    }

    return null;
  }
}
